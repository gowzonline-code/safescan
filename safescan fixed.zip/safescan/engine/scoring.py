"""Weighted scoring, banding and explanation building.

The engine is deliberately independent of Flask: it takes a URL string plus
configuration and returns a ScanResult. This lets the same code run inside the
web application and in the offline batch evaluation (evaluation/run_eval.py).
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from typing import Callable, Iterable, Optional

from .parser import ParsedURL, parse_url
from .rules import (DEFAULT_WEIGHTS, RULES, Brand, LookupResults, RuleConfig,
                    RuleContext)

SCORE_CAP = 100
DEFAULT_BANDS = {"suspicious": 30, "dangerous": 60}   # safe < 30 <= suspicious < 60 <= dangerous

_BRANDS_PATH = os.path.join(os.path.dirname(__file__), "data", "brands.json")


def load_default_brands() -> list[Brand]:
    with open(_BRANDS_PATH, encoding="utf-8") as fh:
        return [Brand(b["name"].lower(), [d.lower() for d in b["domains"]]) for b in json.load(fh)]


@dataclass
class Finding:
    rule_id: str
    name: str
    category: str
    weight: int
    evidence: str
    rationale: str
    advice: str

    @property
    def sentence(self) -> str:
        return f"{self.name}: {self.evidence[0].upper()}{self.evidence[1:]}."


@dataclass
class ScanResult:
    url: str
    normalised: str
    parsed: dict
    score: int
    raw_score: int
    band: str
    findings: list[Finding]
    not_evaluated: list[dict]
    passed: list[str]
    duration_ms: float
    summary: str = ""
    true_destination: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        return d


def assign_band(score: int, bands: dict | None = None) -> str:
    b = bands or DEFAULT_BANDS
    if score >= b["dangerous"]:
        return "dangerous"
    if score >= b["suspicious"]:
        return "suspicious"
    return "safe"


def _summary(band: str, findings: list[Finding], dest: str, not_eval: list[dict]) -> str:
    if not findings:
        s = (f"No warning signs were found in this address. The link goes to {dest}. "
             "This does not guarantee the site is safe - SafeScan only checks the address, not the page.")
    else:
        top = sorted(findings, key=lambda f: -f.weight)[:2]
        names = " and ".join(f.name.lower() for f in top)
        verdict = {"safe": "A minor warning sign was found, but not enough to raise a warning",
                   "suspicious": "Several warning signs were found",
                   "dangerous": "Strong warning signs of phishing were found"}[band]
        s = f"{verdict} (mainly: {names}). The link really goes to {dest}."
    if not_eval:
        s += f" {len(not_eval)} check(s) could not be run and are not included in the score."
    return s


def analyse(
    url: str,
    *,
    weights: Optional[dict] = None,
    enabled: Optional[Iterable[str]] = None,
    brands: Optional[list[Brand]] = None,
    config: Optional[RuleConfig] = None,
    bands: Optional[dict] = None,
    lookup_fn: Optional[Callable[[ParsedURL], LookupResults]] = None,
) -> ScanResult:
    """Analyse a URL. Raises parser.URLValidationError for invalid input.

    lookup_fn, if supplied, performs the optional external lookups (R13-R15).
    When it is None those rules are reported as 'not evaluated' rather than
    silently scoring zero (alternate flow B of the use case).
    """
    t0 = time.perf_counter()
    weights = {**DEFAULT_WEIGHTS, **(weights or {})}
    enabled_set = set(enabled) if enabled is not None else {r.id for r in RULES}
    brands = brands if brands is not None else load_default_brands()
    config = config or RuleConfig()

    parsed = parse_url(url)

    lookups = LookupResults()
    lookup_note = "external lookups are disabled"
    if lookup_fn is not None:
        try:
            lookups = lookup_fn(parsed)
            lookup_note = None
        except Exception as exc:  # never let a lookup failure break the scan
            lookup_note = f"external lookup failed ({type(exc).__name__})"

    ctx = RuleContext(url=parsed, brands=brands, config=config, lookups=lookups)
    findings: list[Finding] = []
    not_evaluated: list[dict] = []
    passed: list[str] = []

    for rule in RULES:
        if rule.id not in enabled_set:
            continue
        if rule.requires_network:
            reason = None
            if lookup_note:
                reason = lookup_note
            elif rule.id == "R13" and lookups.domain_age_days is None:
                reason = lookups.domain_age_error or "registration date unavailable"
            elif rule.id == "R14" and lookups.cert_age_days is None:
                reason = lookups.cert_error or "certificate unavailable"
            elif rule.id == "R15" and lookups.redirect_hops is None:
                reason = lookups.redirect_error or "redirects not checked"
            if reason:
                not_evaluated.append({"rule_id": rule.id, "name": rule.name, "reason": reason})
                continue
        evidence = rule.check(ctx)
        if evidence:
            findings.append(Finding(rule.id, rule.name, rule.category, int(weights.get(rule.id, 0)),
                                    evidence, rule.rationale, rule.advice))
        else:
            passed.append(rule.id)

    raw = sum(f.weight for f in findings)
    score = min(SCORE_CAP, raw)
    band = assign_band(score, bands)
    dest = parsed.registrable_unicode
    findings.sort(key=lambda f: (-f.weight, f.rule_id))
    return ScanResult(
        url=url,
        normalised=parsed.normalised,
        parsed=parsed.to_dict(),
        score=score,
        raw_score=raw,
        band=band,
        findings=findings,
        not_evaluated=not_evaluated,
        passed=passed,
        duration_ms=round((time.perf_counter() - t0) * 1000, 2),
        summary=_summary(band, findings, dest, not_evaluated),
        true_destination=dest,
    )
