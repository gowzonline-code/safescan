"""Supplementary analysis added after pre-marking feedback (Sections 7.6.1, 7.6.2, 7.6.4).

    python -m evaluation.supplementary

Writes results/supplementary_analysis.json with: pairwise phi correlation between rule firings on the
refinement split, a structural comparison of the two classes in the held-out split, 95% Wilson
confidence intervals for the held-out v2 metrics, and precision at realistic phishing prevalence.
"""
import json
import math
import os
import statistics
import sys
from urllib.parse import urlsplit

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from evaluation.run_eval import V2_RULES, load_rows, restrict, scan_rows  # noqa: E402
from engine import DEFAULT_WEIGHTS  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
PLATFORMS = ["blogspot", "pages.dev", "netlify.app", "vercel.app", "firebaseapp.com", "weebly", "web.app",
             "duckdns", "github.io", "wixsite", "000webhost", "glitch.me", "appspot.com"]


def wilson(k, n, z=1.96):
    p = k / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    m = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return [round((c - m) / d, 3), round((c + m) / d, 3)]


def main():
    data = os.path.join(HERE, "data", "dataset.csv")
    ref = restrict(scan_rows(load_rows(data, "refine"), DEFAULT_WEIGHTS), V2_RULES)
    fired = [set(r["fired"]) for r in ref]
    n = len(fired)
    rules = sorted(V2_RULES)
    pairs = []
    for i, a in enumerate(rules):
        for b in rules[i + 1:]:
            n11 = sum(1 for f in fired if a in f and b in f)
            na = sum(1 for f in fired if a in f)
            nb = sum(1 for f in fired if b in f)
            den = math.sqrt(na * (n - na) * nb * (n - nb))
            if den:
                pairs.append({"a": a, "b": b, "phi": round((n11 * n - na * nb) / den, 3)})
    pairs.sort(key=lambda x: -x["phi"])

    hold = load_rows(data, "holdout")
    classes = {}
    for lab, name in ((1, "phishing"), (0, "benign")):
        us = [r["url"] for r in hold if int(r["label"]) == lab]
        sp = [urlsplit(u) for u in us]
        lens = [len(u) for u in us]
        classes[name] = {
            "n": len(us), "mean_length": round(statistics.mean(lens)), "median_length": statistics.median(lens),
            "with_path": round(sum(s.path not in ("", "/") for s in sp) / len(us), 3),
            "with_query": round(sum(bool(s.query) for s in sp) / len(us), 3),
            "https": round(sum(s.scheme == "https" for s in sp) / len(us), 3),
            "free_hosting": round(sum(any(p in u.lower() for p in PLATFORMS) for u in us) / len(us), 3)}

    tp, fp, n_pos, n_neg = 314, 11, 600, 600   # frozen v2, Table 7-6
    recall, fpr = tp / n_pos, fp / n_neg
    prevalence = {f"{p:.0%}": round(recall * p / (recall * p + fpr * (1 - p)), 3) for p in (0.01, 0.05, 0.10, 0.50)}
    out = {"top_rule_correlations_refine": pairs[:10], "class_structure_holdout": classes,
           "ci95": {"recall": wilson(tp, n_pos), "precision": wilson(tp, tp + fp), "fpr": wilson(fp, n_neg)},
           "precision_at_prevalence": prevalence}
    with open(os.path.join(HERE, "results", "supplementary_analysis.json"), "w") as fh:
        json.dump(out, fh, indent=2)
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
