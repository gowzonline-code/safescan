# SafeScan - An Explainable Heuristic Framework for Phishing URL Detection

PSB601IT Individual Cyber Security Project - Gowtham Karthik Raju (supervisor: Suryanto (Ryan)).

SafeScan checks a URL against weighted heuristic rules and returns a 0-100 score, a band
(safe / suspicious / dangerous) and an itemised explanation of every rule that fired. It never fetches
or renders the page. It is delivered as a secured Flask web application with registration, Argon2id
password hashing, role-based access control (default deny), an append-only audit log, rate limiting,
CSRF protection and field-level encryption at rest.

## Project layout

```
engine/            framework-independent analysis engine (parser, rules R01-R19, scoring, SSRF-safe lookups)
  data/            bundled Public Suffix List, Unicode TS #39 confusables, default brand list
safescan/          Flask application (views, security modules, templates, schema.sql)
evaluation/        dataset builder, refinement, held-out evaluation, synthetic test, VirusTotal baseline
  results/         every number used in the report (JSON/CSV), junit.xml, bandit.json, pip_audit.txt
  figures/         charts used in Chapter 7
tests/             108 pytest tests (unit, integration, security)
docs/diagrams/     PlantUML sources + PNGs (use case, class, activity, sequence, ERD, architecture, deployment)
docs/wireframes/   low-fidelity UI prototypes (Chapter 6)
docs/screenshots/  implemented UI (Chapter 7)
instruments/       interview guide, questionnaire, consent sheet, analysis script (Chapter 4)
```

## Run it locally (Windows / macOS / Linux, Python 3.11+)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate      macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python scripts/generate_keys.py          # creates instance/safescan.env (secret keys, never commit)
flask --app safescan create-admin        # there are no default accounts
python run.py                            # http://127.0.0.1:5000
```

Run the tests: `python -m pytest -q --cov=engine --cov=safescan`

## Reproduce the evaluation

```bash
# 1. datasets (already in evaluation/data/dataset.csv; to rebuild from fresh feeds):
python -m evaluation.build_dataset --phish <phishing list or PhishTank CSV> --benign <Tranco/top-1M list> \
       --benign-urls <CSV with url,label 'good'> --recent <newest phishing feed>
# 2. calibrate weights on the 40% refinement split (writes frozen weights/bands)
python -m evaluation.refine
# 3. score the 60% held-out split, the recent set and draw the figures
python -m evaluation.evaluate_all
# 4. character-level capability test (synthetic homographs/typosquats)
python -m evaluation.synthetic
# 5. VirusTotal baseline (needs a free API key, ~1 hour at the free rate limit)
export VT_API_KEY=...   # Windows: set VT_API_KEY=...
python -m evaluation.vt_baseline --n 150 --recent 50
```

## Deployment plan (production)

1. Ubuntu 24.04 LTS VM; create a `safescan` system user; `git clone` to `/opt/safescan`.
2. `python3 -m venv /opt/safescan/.venv && .venv/bin/pip install -r requirements.txt gunicorn`.
3. Put keys in `/etc/safescan/safescan.env` (mode 600, owner `safescan`); set `SAFESCAN_ENV=production`
   and `SAFESCAN_DATABASE=/var/lib/safescan/safescan.db`. Production refuses to start without keys.
4. `flask --app safescan init-db` and `flask --app safescan create-admin`.
5. systemd unit running `gunicorn -w 2 -b 127.0.0.1:8000 "safescan:create_app('production')"`.
6. Nginx reverse proxy with Let's Encrypt TLS, HTTP->HTTPS redirect, `client_max_body_size 16k`, `server_tokens off`;
   add werkzeug `ProxyFix` so audit logs record the real client IP.
7. Daily cron: `flask --app safescan purge` (retention) and an encrypted backup of the DB file.
8. Smoke test: register, scan, check audit log; run OWASP ZAP baseline scan against the HTTPS URL.

## Data sources used in the evaluation (collected 6 Oct 2026)

- Phishing: Phishing.Database "ACTIVE" list (aggregates PhishTank, OpenPhish and other feeds) - 1,000 sampled.
- Recently reported phishing: OpenPhish public feed (newest 300 entries; 237 after cleaning).
- Benign homepages: top-1M ranked domain list (250 from top 10k, 250 from ranks 10k-1M).
- Benign deep links: "good" URLs of the public malicious-URL dataset by Faizan Ahmad (500 sampled).
- tranco-list.eu and phishtank.org were not reachable from the build environment; the scripts accept
  Tranco and PhishTank files directly if you want to re-run with those exact sources.
