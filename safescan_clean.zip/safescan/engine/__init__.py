"""SafeScan heuristic analysis engine (framework-independent)."""
from .parser import ParsedURL, URLValidationError, parse_url
from .rules import DEFAULT_WEIGHTS, RULES, RULES_BY_ID, Brand, LookupResults, RuleConfig
from .scoring import DEFAULT_BANDS, Finding, ScanResult, analyse, assign_band, load_default_brands

__all__ = [
    "ParsedURL", "URLValidationError", "parse_url", "DEFAULT_WEIGHTS", "RULES", "RULES_BY_ID",
    "Brand", "LookupResults", "RuleConfig", "DEFAULT_BANDS", "Finding", "ScanResult", "analyse",
    "assign_band", "load_default_brands",
]
