"""Optional external lookups for rules R13-R15 (increment 5).

Security design (OWASP A10 Server-Side Request Forgery):
  * the host is resolved ONCE and every resolved address must be a public,
    globally routable address - private, loopback, link-local (incl. cloud
    metadata 169.254.169.254), multicast and reserved ranges are refused;
  * the connection is made to the vetted IP address (pinned), so a second DNS
    answer cannot redirect it (DNS rebinding);
  * only ports 80 and 443 are permitted;
  * redirects are never followed automatically - each Location is re-validated
    as a new request, up to a hop limit;
  * only HEAD requests are sent and no response body is ever read;
  * every operation has a strict timeout.

Nothing here renders or executes content from the scanned site.
"""
from __future__ import annotations

import datetime as dt
import http.client
import ipaddress
import socket
import ssl
from typing import Callable, Optional
from urllib.parse import urljoin, urlsplit

from .parser import ParsedURL, URLValidationError, parse_url
from .rules import LookupResults

TIMEOUT = 4.0
ALLOWED_PORTS = {80, 443}
MAX_HOPS = 5


class SSRFBlocked(Exception):
    """Raised when a destination is not safe for the server to contact."""


def _is_public(addr: str) -> bool:
    ip = ipaddress.ip_address(addr)
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return ip.is_global and not (ip.is_private or ip.is_loopback or ip.is_link_local
                                 or ip.is_multicast or ip.is_reserved or ip.is_unspecified)


def resolve_safe(host: str, port: int) -> str:
    """Resolve host and return one vetted public IP, or raise SSRFBlocked."""
    if port not in ALLOWED_PORTS:
        raise SSRFBlocked(f"port {port} is not permitted")
    try:
        infos = socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        raise SSRFBlocked(f"host does not resolve ({exc.strerror})") from exc
    addrs = sorted({i[4][0] for i in infos})
    if not addrs:
        raise SSRFBlocked("host does not resolve")
    for a in addrs:
        if not _is_public(a):
            raise SSRFBlocked(f"host resolves to a non-public address ({a})")
    return addrs[0]


# ------------------------------------------------------------------ WHOIS (R13)

def domain_age_days(registrable: str, whois_fn: Optional[Callable] = None) -> int:
    """Return the age of a registrable domain in days using WHOIS."""
    if whois_fn is None:
        import whois  # python-whois; imported lazily, optional dependency
        whois_fn = whois.whois
    rec = whois_fn(registrable)
    created = rec.get("creation_date") if isinstance(rec, dict) else getattr(rec, "creation_date", None)
    if isinstance(created, list):
        created = min(c for c in created if c)
    if not created:
        raise LookupError("no creation date in WHOIS record")
    if isinstance(created, str):
        created = dt.datetime.fromisoformat(created)
    if created.tzinfo is None:
        created = created.replace(tzinfo=dt.timezone.utc)
    return max(0, (dt.datetime.now(dt.timezone.utc) - created).days)


# ------------------------------------------------------------------ TLS (R14)

def cert_age_days(host: str) -> int:
    from cryptography import x509
    ip = resolve_safe(host, 443)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE   # we only read metadata; trust is not the question here
    with socket.create_connection((ip, 443), timeout=TIMEOUT) as sock:
        with ctx.wrap_socket(sock, server_hostname=host) as tls:
            der = tls.getpeercert(binary_form=True)
    cert = x509.load_der_x509_certificate(der)
    issued = cert.not_valid_before_utc
    return max(0, (dt.datetime.now(dt.timezone.utc) - issued).days)


# ------------------------------------------------------------------ redirects (R15)

def redirect_chain(url: str, max_hops: int = MAX_HOPS) -> list[str]:
    chain = [url]
    current = url
    for _ in range(max_hops):
        parts = urlsplit(current)
        scheme = parts.scheme.lower()
        if scheme not in ("http", "https"):
            break
        port = parts.port or (443 if scheme == "https" else 80)
        host = parts.hostname or ""
        ip = resolve_safe(host, port)
        path = (parts.path or "/") + (("?" + parts.query) if parts.query else "")
        # Connect to the vetted IP (pinned), presenting the real name for SNI/Host.
        sock = socket.create_connection((ip, port), timeout=TIMEOUT)
        if scheme == "https":
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            sock = ctx.wrap_socket(sock, server_hostname=host)
        conn = http.client.HTTPConnection(host, port, timeout=TIMEOUT)
        conn.sock = sock  # pre-connected: http.client will not resolve the name again
        try:
            conn.putrequest("HEAD", path, skip_host=True)
            conn.putheader("Host", host)
            conn.putheader("User-Agent", "SafeScan/1.0 (research prototype; metadata only)")
            conn.endheaders()
            resp = conn.getresponse()
            location = resp.getheader("Location")
            status = resp.status
        finally:
            conn.close()          # body is never read
        if status in (301, 302, 303, 307, 308) and location:
            nxt = urljoin(current, location)
            try:
                parse_url(nxt)
            except URLValidationError:
                break
            chain.append(nxt)
            current = nxt
        else:
            break
    return chain


# ------------------------------------------------------------------ combined

def make_lookup_fn(cache_get: Optional[Callable] = None, cache_set: Optional[Callable] = None,
                   do_whois: bool = True, do_tls: bool = True, do_redirects: bool = True,
                   whois_fn: Optional[Callable] = None) -> Callable[[ParsedURL], LookupResults]:
    """Build a lookup function with optional caching hooks (key -> value)."""

    def cached(key: str, fn: Callable):
        if cache_get:
            hit = cache_get(key)
            if hit is not None:
                return hit
        val = fn()
        if cache_set:
            cache_set(key, val)
        return val

    def lookup(p: ParsedURL) -> LookupResults:
        res = LookupResults()
        if do_whois and not p.is_ip:
            try:
                res.domain_age_days = cached(f"whois:{p.registrable}",
                                             lambda: domain_age_days(p.registrable, whois_fn))
            except Exception as exc:
                res.domain_age_error = f"WHOIS lookup failed or timed out ({type(exc).__name__})"
        if do_tls and p.scheme == "https":
            try:
                res.cert_age_days = cached(f"tls:{p.host}", lambda: cert_age_days(p.host))
            except SSRFBlocked as exc:
                res.cert_error = f"not contacted: {exc}"
            except Exception as exc:
                res.cert_error = f"certificate could not be read ({type(exc).__name__})"
        elif do_tls:
            res.cert_error = "site does not use HTTPS"
        if do_redirects:
            try:
                chain = redirect_chain(p.normalised)
                res.redirect_chain = chain
                res.redirect_hops = len(chain) - 1
            except SSRFBlocked as exc:
                res.redirect_error = f"not contacted: {exc}"
            except Exception as exc:
                res.redirect_error = f"redirects could not be checked ({type(exc).__name__})"
        return res

    return lookup
