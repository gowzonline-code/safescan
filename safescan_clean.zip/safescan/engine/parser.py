"""URL validation, normalisation and parsing.

The parser never contacts the network. It turns an untrusted string into a
structured ParsedURL, identifying the registrable domain against the Public
Suffix List (bundled snapshot, private section included so that hosting
platforms such as github.io or workers.dev are treated as public suffixes).
"""
from __future__ import annotations

import ipaddress
import os
import re
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from urllib.parse import urlsplit

import tldextract

from .unicode_tools import to_ascii_host, to_unicode_label

MAX_URL_LENGTH = 2048
ALLOWED_SCHEMES = ("http", "https")
_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")
_HOST_ALLOWED = re.compile(r"^[A-Za-z0-9.\-_]+$")

_PSL_PATH = os.path.join(os.path.dirname(__file__), "data", "public_suffix_list.dat")


class URLValidationError(ValueError):
    """Raised when input is not an acceptable http(s) URL."""


@lru_cache(maxsize=1)
def _extractor() -> tldextract.TLDExtract:
    # Path.as_uri() gives a valid file URL on every OS ("file:///C:/..." on
    # Windows, "file:///home/..." on Linux). Plain "file://" + path breaks on
    # Windows because the drive letter is read as a host name.
    ext = tldextract.TLDExtract(
        suffix_list_urls=(Path(_PSL_PATH).resolve().as_uri(),),
        cache_dir=None,
        fallback_to_snapshot=True,
        include_psl_private_domains=True,
    )
    try:
        ext("www.example.co.uk")          # force the list to load now
        return ext
    except Exception:
        # Last resort: tldextract's own bundled snapshot of the same list.
        return tldextract.TLDExtract(suffix_list_urls=(), cache_dir=None,
                                     fallback_to_snapshot=True, include_psl_private_domains=True)


@dataclass
class ParsedURL:
    original: str
    normalised: str
    scheme: str
    host: str                 # ASCII / punycode form, lower-case
    host_unicode: str         # decoded form, for display and homograph checks
    port: int | None
    path: str
    query: str
    fragment: str
    userinfo: str
    is_ip: bool
    ip_value: str | None
    subdomain: str            # e.g. "secure.login" (ASCII)
    domain: str               # registrable label, e.g. "paypal" (ASCII)
    suffix: str               # public suffix, e.g. "com" or "co.uk"
    labels: list[str] = field(default_factory=list)          # ASCII host labels
    unicode_labels: list[str] = field(default_factory=list)  # decoded host labels

    @property
    def registrable(self) -> str:
        if self.is_ip:
            return self.host
        return f"{self.domain}.{self.suffix}" if self.suffix else self.domain

    @property
    def registrable_unicode(self) -> str:
        if self.is_ip:
            return self.host
        dom = to_unicode_label(self.domain)
        suf = ".".join(to_unicode_label(s) for s in self.suffix.split(".")) if self.suffix else ""
        return f"{dom}.{suf}" if suf else dom

    @property
    def subdomain_labels(self) -> list[str]:
        return [s for s in self.subdomain.split(".") if s] if self.subdomain else []

    def to_dict(self) -> dict:
        return {
            "normalised": self.normalised,
            "scheme": self.scheme,
            "host": self.host,
            "host_unicode": self.host_unicode,
            "port": self.port,
            "path": self.path,
            "query": self.query,
            "userinfo": self.userinfo,
            "is_ip": self.is_ip,
            "subdomain": self.subdomain,
            "registrable_domain": self.registrable,
            "registrable_domain_unicode": self.registrable_unicode,
            "suffix": self.suffix,
        }


def _parse_ip(host: str) -> str | None:
    """Recognise dotted, bracketed IPv6 and integer/hex IPv4 hosts."""
    h = host.strip("[]")
    try:
        return str(ipaddress.ip_address(h))
    except ValueError:
        pass
    # Browsers accept a single integer or hex value as an IPv4 address,
    # e.g. http://3232235777/ == http://192.168.1.1/
    try:
        if re.fullmatch(r"0x[0-9a-fA-F]+", h):
            val = int(h, 16)
        elif re.fullmatch(r"\d+", h):
            val = int(h)
        else:
            return None
        if 0 <= val <= 0xFFFFFFFF:
            return str(ipaddress.IPv4Address(val))
    except ValueError:
        return None
    return None


def validate_and_normalise(raw: str) -> str:
    """Reject unsafe or malformed input and return a canonical URL string."""
    if raw is None:
        raise URLValidationError("No URL was supplied.")
    url = raw.strip()
    if not url:
        raise URLValidationError("No URL was supplied.")
    if len(url) > MAX_URL_LENGTH:
        raise URLValidationError(f"URL is longer than {MAX_URL_LENGTH} characters.")
    if _CONTROL_CHARS.search(url):
        raise URLValidationError("URL contains control characters.")
    if " " in url:
        raise URLValidationError("URL contains spaces.")
    if "://" not in url:
        # Reject other schemes that have no "//" (javascript:, data:, mailto:)
        m = re.match(r"^([A-Za-z][A-Za-z0-9+.\-]*):", url)
        if m and not re.match(r"^[^:/]+:\d", url):
            raise URLValidationError(f"Scheme '{m.group(1)}' is not supported; only http and https.")
        url = "http://" + url
    scheme = url.split("://", 1)[0].lower()
    if scheme not in ALLOWED_SCHEMES:
        raise URLValidationError(f"Scheme '{scheme}' is not supported; only http and https.")
    return scheme + url[len(scheme):]


def parse_url(raw: str) -> ParsedURL:
    normalised = validate_and_normalise(raw)
    try:
        parts = urlsplit(normalised)
        port = parts.port
    except ValueError as exc:
        raise URLValidationError(f"URL could not be parsed: {exc}") from exc

    netloc = parts.netloc
    userinfo = ""
    if "@" in netloc:
        userinfo, _, _ = netloc.rpartition("@")
    hostname = parts.hostname or ""
    if not hostname:
        raise URLValidationError("URL has no host.")
    hostname = hostname.rstrip(".")

    ip_value = _parse_ip(hostname)
    is_ip = ip_value is not None

    if is_ip:
        host_ascii = hostname.lower()
    else:
        host_ascii = to_ascii_host(hostname)
        if not _HOST_ALLOWED.match(host_ascii):
            raise URLValidationError("Host contains characters that are not valid in a domain name.")
        if len(host_ascii) > 253 or any(len(l) > 63 or not l for l in host_ascii.split(".")):
            raise URLValidationError("Host is not a valid domain name.")

    labels = host_ascii.split(".") if not is_ip else [host_ascii]
    unicode_labels = [to_unicode_label(l) for l in labels] if not is_ip else labels
    host_unicode = ".".join(unicode_labels)

    if is_ip:
        sub, dom, suf = "", host_ascii, ""
    else:
        ext = _extractor()(host_ascii)
        sub, dom, suf = ext.subdomain, ext.domain, ext.suffix
        if not dom and suf:
            # host is itself a public suffix (e.g. "github.io")
            dom, suf = suf.split(".", 1)[0], ".".join(suf.split(".")[1:])

    return ParsedURL(
        original=raw,
        normalised=normalised,
        scheme=parts.scheme.lower(),
        host=host_ascii,
        host_unicode=host_unicode,
        port=port,
        path=parts.path or "",
        query=parts.query or "",
        fragment=parts.fragment or "",
        userinfo=userinfo,
        is_ip=is_ip,
        ip_value=ip_value,
        subdomain=sub,
        domain=dom,
        suffix=suf,
        labels=labels,
        unicode_labels=unicode_labels,
    )
