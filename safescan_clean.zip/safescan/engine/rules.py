"""The SafeScan heuristic rule set (Table 3-3 of the proposal).

Each rule is a pure function of a RuleContext. It returns None when it does not
fire, or a short evidence string describing exactly what it saw in this URL.
The evidence string is what turns a generic rule description into a specific,
checkable explanation for the user.

Rules R13-R15 need network lookups; they read pre-computed lookup results from
the context and never contact the network themselves.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Optional

import Levenshtein

from .parser import ParsedURL
from .unicode_tools import is_mixed_script, skeleton, to_unicode_label

DEFAULT_HIGH_RISK_TLDS = frozenset({
    "xyz", "top", "tk", "ml", "ga", "cf", "gq", "buzz", "icu", "cyou", "sbs",
    "cfd", "bond", "click", "link", "rest", "online", "site", "live", "club",
    "work", "support", "monster", "quest", "lat", "mom", "fun", "shop", "store",
})


@dataclass
class Brand:
    name: str
    domains: list[str]

    @property
    def skeleton(self) -> str:
        return skeleton(self.name)


@dataclass
class RuleConfig:
    """Thresholds for the rules. Values are the proposal's provisional values."""
    subdomain_depth: int = 4          # R03
    url_length: int = 75              # R04
    hyphen_count: int = 3             # R05 (fires when count > value)
    digit_density: float = 0.30       # R06 (fires when density > value)
    similarity_threshold: float = 0.80  # R11 normalised Levenshtein similarity
    min_brand_length_for_edit_distance: int = 4  # R11
    domain_age_days: int = 30         # R13
    cert_age_days: int = 7            # R14
    redirect_hops: int = 2            # R15 (fires when hops > value)
    high_risk_tlds: frozenset = DEFAULT_HIGH_RISK_TLDS


@dataclass
class LookupResults:
    """Results of optional external lookups. None means 'not evaluated'."""
    domain_age_days: Optional[int] = None
    domain_age_error: Optional[str] = None
    cert_age_days: Optional[int] = None
    cert_error: Optional[str] = None
    redirect_hops: Optional[int] = None
    redirect_chain: list[str] = field(default_factory=list)
    redirect_error: Optional[str] = None


@dataclass
class RuleContext:
    url: ParsedURL
    brands: list[Brand]
    config: RuleConfig
    lookups: LookupResults
    # Shared state so that one impersonation is attributed to the most specific
    # rule only (R10 before R11) and is not double counted.
    matched_brands: dict = field(default_factory=dict)


@dataclass(frozen=True)
class RuleSpec:
    id: str
    name: str
    category: str
    default_weight: int
    rationale: str           # why this property is suspicious (plain language)
    advice: str              # what the user can check for themselves
    check: Callable[[RuleContext], Optional[str]]
    requires_network: bool = False


# ---------------------------------------------------------------- helpers

def _official(brand: Brand, registrable: str) -> bool:
    reg = registrable.lower()
    return any(reg == d or reg.endswith("." + d) for d in brand.domains)


def _tokens(text: str) -> list[str]:
    return [t for t in re.split(r"[^a-z0-9]+", text.lower()) if t]


def _host_without_suffix(u: ParsedURL) -> str:
    """Host minus its public suffix, in decoded (Unicode) form so that the
    digits inside punycode encodings (xn--80ak6aa...) are not counted."""
    raw = ".".join(p for p in (u.subdomain, u.domain) if p)
    return ".".join(to_unicode_label(l) for l in raw.split(".")) if raw else ""


# ---------------------------------------------------------------- lexical

def r01_ip_host(ctx: RuleContext) -> Optional[str]:
    u = ctx.url
    if u.is_ip:
        if u.ip_value and u.ip_value != u.host.strip("[]"):
            return f"the host '{u.host}' is an IP address written in an unusual form (it means {u.ip_value})"
        return f"the host is the IP address {u.ip_value}"
    return None


def r02_at_symbol(ctx: RuleContext) -> Optional[str]:
    u = ctx.url
    if u.userinfo:
        return (f"the text '{u.userinfo}' appears before an @ sign; browsers ignore it and "
                f"actually go to '{u.host_unicode}'")
    return None


def r03_subdomain_depth(ctx: RuleContext) -> Optional[str]:
    labels = ctx.url.subdomain_labels
    if not ctx.url.is_ip and len(labels) >= ctx.config.subdomain_depth:
        return f"the address has {len(labels)} levels of subdomain ('{ctx.url.subdomain}') in front of the real domain"
    return None


def r04_url_length(ctx: RuleContext) -> Optional[str]:
    n = len(ctx.url.normalised)
    if n > ctx.config.url_length:
        return f"the URL is {n} characters long (threshold {ctx.config.url_length})"
    return None


def r05_hyphens(ctx: RuleContext) -> Optional[str]:
    if ctx.url.is_ip:
        return None
    host = _host_without_suffix(ctx.url)
    n = host.count("-")
    if n > ctx.config.hyphen_count:
        return f"the host '{host}' contains {n} hyphens"
    return None


def r06_digit_density(ctx: RuleContext) -> Optional[str]:
    if ctx.url.is_ip:
        return None
    host = _host_without_suffix(ctx.url)
    alnum = [c for c in host if c.isalnum()]
    if len(alnum) < 4:
        return None
    digits = sum(c.isdigit() for c in alnum)
    density = digits / len(alnum)
    if density > ctx.config.digit_density:
        return f"{digits} of the {len(alnum)} letters and numbers in the host ({density:.0%}) are digits"
    return None


def r07_risky_tld(ctx: RuleContext) -> Optional[str]:
    if ctx.url.is_ip or not ctx.url.suffix:
        return None
    tld = ctx.url.suffix.split(".")[-1].lower()
    if tld in ctx.config.high_risk_tlds:
        return f"the domain ends in '.{tld}', a top-level domain that is heavily used in abuse reports"
    return None


# ---------------------------------------------------------------- homograph

def r08_punycode(ctx: RuleContext) -> Optional[str]:
    u = ctx.url
    idn = [l for l in u.labels if l.startswith("xn--")]
    if idn:
        decoded = ", ".join(f"'{l}' displays as '{to_unicode_label(l)}'" for l in idn)
        return f"the host contains internationalised (punycode) labels: {decoded}"
    return None


def r09_mixed_script(ctx: RuleContext) -> Optional[str]:
    for label in ctx.url.unicode_labels:
        mixed, scripts = is_mixed_script(label)
        if mixed:
            return (f"the label '{label}' mixes characters from different alphabets "
                    f"({', '.join(sorted(s.title() for s in scripts))})")
    return None


def r10_confusable_brand(ctx: RuleContext) -> Optional[str]:
    u = ctx.url
    if u.is_ip:
        return None
    candidates = [to_unicode_label(u.domain)] + [l for l in u.unicode_labels if l != to_unicode_label(u.domain)]
    for label in candidates:
        sk = skeleton(label)
        for brand in ctx.brands:
            if label.lower() == brand.name:
                continue  # genuine spelling, not a look-alike
            if sk == brand.skeleton and not _official(brand, u.registrable):
                ctx.matched_brands[brand.name] = "R10"
                return (f"'{label}' is built from look-alike characters and reads as '{brand.name}', "
                        f"but the site is not one of {brand.name}'s domains")
    return None


# ---------------------------------------------------------------- typosquat

def r11_edit_distance(ctx: RuleContext) -> Optional[str]:
    u = ctx.url
    if u.is_ip or not u.domain:
        return None
    label = u.domain.lower()
    best = None
    for brand in ctx.brands:
        if brand.name in ctx.matched_brands:
            continue
        if len(brand.name) < ctx.config.min_brand_length_for_edit_distance:
            continue
        if label == brand.name or _official(brand, u.registrable):
            continue
        dist = Levenshtein.distance(label, brand.name)
        sim = 1 - dist / max(len(label), len(brand.name))
        if dist >= 1 and sim >= ctx.config.similarity_threshold:
            if best is None or sim > best[2]:
                best = (brand, dist, sim)
    if best:
        brand, dist, sim = best
        ctx.matched_brands[brand.name] = "R11"
        return (f"the domain name '{label}' is {dist} character edit(s) away from '{brand.name}' "
                f"({sim:.0%} similar) but is not a {brand.name} domain")
    return None


def r12_brand_outside_domain(ctx: RuleContext) -> Optional[str]:
    u = ctx.url
    places = {
        "subdomain": _tokens(u.subdomain) if not u.is_ip else [],
        "path": _tokens(u.path),
        "query": _tokens(u.query),
        "user-info": _tokens(u.userinfo),
    }
    for brand in ctx.brands:
        if brand.name in ctx.matched_brands or _official(brand, u.registrable):
            continue
        for where, toks in places.items():
            if brand.name in toks:
                ctx.matched_brands[brand.name] = "R12"
                return (f"the brand name '{brand.name}' appears in the {where}, but the site actually "
                        f"belongs to '{u.registrable_unicode}', which is not a {brand.name} domain")
    return None


# ---------------------------------------------------------------- network-derived

def r13_domain_age(ctx: RuleContext) -> Optional[str]:
    age = ctx.lookups.domain_age_days
    if age is not None and age < ctx.config.domain_age_days:
        return f"the domain was registered {age} day(s) ago"
    return None


def r14_cert_age(ctx: RuleContext) -> Optional[str]:
    age = ctx.lookups.cert_age_days
    if age is not None and age < ctx.config.cert_age_days:
        return f"the site's TLS certificate was issued {age} day(s) ago"
    return None


def r15_redirects(ctx: RuleContext) -> Optional[str]:
    hops = ctx.lookups.redirect_hops
    if hops is not None and hops > ctx.config.redirect_hops:
        return f"the link redirects {hops} times before reaching its destination"
    return None


RULES: list[RuleSpec] = [
    RuleSpec("R01", "IP address used as host", "Lexical", 20,
             "Legitimate services are reached by name. Using a raw IP address avoids registering a domain, which leaves no traceable owner.",
             "Ask yourself why a real company would send you to a bare number instead of its website name.", r01_ip_host),
    RuleSpec("R02", "@ symbol in address", "Lexical", 20,
             "Everything before an @ in a web address is ignored by the browser, so a trusted name can be shown while the link goes elsewhere.",
             "Look only at what comes after the @ - that is where the link really goes.", r02_at_symbol),
    RuleSpec("R03", "Deep subdomain nesting", "Lexical", 10,
             "Stacking many subdomains lets an attacker put a familiar name at the start of the address, far from the domain that really owns the site.",
             "Read the address from the right: the part just before .com/.sg etc. is the real owner.", r03_subdomain_depth),
    RuleSpec("R04", "Very long URL", "Lexical", 8,
             "Long addresses push the real domain out of view in the address bar and in previews.",
             "Expand the full link and find the domain before the first single '/'.", r04_url_length),
    RuleSpec("R05", "Many hyphens in host", "Lexical", 8,
             "Legitimate domains rarely use several hyphens; phishing domains use them to join brand words together (e.g. secure-login-bank-verify).",
             "Check whether the hyphenated name is really the organisation's official domain.", r05_hyphens),
    RuleSpec("R06", "High digit density in host", "Lexical", 8,
             "Numbers mixed into a host name are common in throw-away and machine-generated phishing domains, and in digit-for-letter swaps.",
             "Compare the name carefully with the organisation's real address.", r06_digit_density),
    RuleSpec("R07", "High-risk top-level domain", "Lexical", 10,
             "Some top-level domains are cheap with weak registration checks and are over-represented in abuse reports. This alone does not make a site malicious.",
             "Treat it as a reason for extra care, not proof of harm.", r07_risky_tld),
    RuleSpec("R08", "Punycode label in host", "Homograph", 12,
             "An xn-- label means the name contains non-English characters, which can be used to imitate familiar names.",
             "Look at the decoded name shown in the report and compare it to the real brand.", r08_punycode),
    RuleSpec("R09", "Mixed alphabets in one label", "Homograph", 25,
             "A single word that mixes alphabets (e.g. Latin and Cyrillic) has no normal linguistic reason and is the signature of a homograph attack.",
             "Do not trust how the name looks - the characters are not what they seem.", r09_mixed_script),
    RuleSpec("R10", "Look-alike characters imitate a brand", "Homograph", 25,
             "The name uses characters that look identical to a well-known brand's name (per Unicode TS #39) but is not that brand's domain.",
             "Type the brand's address yourself instead of following the link.", r10_confusable_brand),
    RuleSpec("R11", "Near-miss spelling of a brand", "Typosquat", 22,
             "The domain is a slight misspelling of a commonly impersonated brand - a typosquatting registration.",
             "Spell the domain out letter by letter and compare it with the brand's real domain.", r11_edit_distance),
    RuleSpec("R12", "Brand name outside the real domain", "Typosquat", 18,
             "A brand name placed in a subdomain or path, while the site is owned by an unrelated domain, is a direct impersonation attempt.",
             "Ignore brand names anywhere except the registered domain itself.", r12_brand_outside_domain),
    RuleSpec("R13", "Recently registered domain", "Registration", 20,
             "Phishing domains are disposable and are usually used within days of registration.",
             "Be very wary of a 'bank' or 'service' whose domain is only days old.", r13_domain_age, True),
    RuleSpec("R14", "Very new TLS certificate", "Certificate", 6,
             "HTTPS proves only encryption, not honesty. A certificate issued days ago supports a throw-away-site conclusion when other signs are present.",
             "The padlock does not mean a site is safe.", r14_cert_age, True),
    RuleSpec("R15", "Long redirect chain", "Redirect", 10,
             "Several redirects hide the final destination and help evade reputation checks.",
             "Check where the link finally lands before entering anything.", r15_redirects, True),
]

# ------------------------------------------------------------------ extension rules
# R16-R19 were NOT in the proposal's rule set (Table 3-3). They were identified
# by error analysis of false negatives on the 40% refinement split only
# (report Section 7.5) and are evaluated separately as "rule set v2".

SENSITIVE_TOKENS = frozenset({
    # Garera et al. (2007) keyword feature, plus modern credential-harvest terms
    "secure", "account", "webscr", "login", "signin", "banking", "confirm", "ebayisapi",
    "verify", "verification", "password", "passwd", "wallet", "authenticate", "auth",
    "unlock", "suspended", "recover", "validation", "update", "billing", "logon", "sso",
})

FREE_HOSTING_SUFFIXES = frozenset({
    "pages.dev", "workers.dev", "r2.dev", "netlify.app", "vercel.app", "web.app", "firebaseapp.com",
    "github.io", "gitlab.io", "appspot.com", "repl.co", "replit.app", "webflow.io", "glitch.me",
    "herokuapp.com", "onrender.com", "fly.dev", "surge.sh", "ngrok.io", "ngrok-free.app",
    "000webhostapp.com", "weebly.com", "wixsite.com", "blogspot.com", "yolasite.com", "square.site",
    "godaddysites.com", "mybluehost.me", "ddns.net", "duckdns.org", "no-ip.org", "hopto.org",
    "freenom.com", "azurewebsites.net", "windows.net", "translate.goog", "ipfs.io", "dweb.link",
    "my.id", "framer.app", "carrd.co", "cprapid.com", "cloudclusters.net", "web.core.windows.net",
    "s3.amazonaws.com", "storage.googleapis.com", "firebasestorage.app", "jimdosite.com",
    "sites.google.com", "notion.site", "typedream.app", "wcomhost.com", "gb.net", "ukit.me",
})

_EMAIL_RE = re.compile(r"[a-z0-9._%+\-]+(@|%40)[a-z0-9.\-]+\.[a-z]{2,}", re.I)


def r16_sensitive_keyword(ctx: RuleContext) -> Optional[str]:
    u = ctx.url
    toks = set(_tokens(u.subdomain)) | set(_tokens(u.domain)) | set(_tokens(u.path)) | set(_tokens(u.query))
    hits = sorted(toks & SENSITIVE_TOKENS)
    if hits:
        return f"the address contains account-related words ({', '.join(hits[:4])}) often used to make a fake login page look official"
    return None


def r17_free_hosting(ctx: RuleContext) -> Optional[str]:
    u = ctx.url
    if u.is_ip:
        return None
    host = u.host.lower()
    for suf in FREE_HOSTING_SUFFIXES:
        # the platform's own site (e.g. blogspot.com itself) is not user content;
        # this exclusion was added after the held-out error analysis (report 7.6.7)
        if host.endswith("." + suf) and host != "www." + suf:
            return (f"the site is hosted on '{suf}', a free or instant hosting service where anyone can "
                    f"create a page in minutes without verifying who they are")
    return None


def r18_embedded_email(ctx: RuleContext) -> Optional[str]:
    u = ctx.url
    for where, text in (("query", u.query), ("path", u.path), ("fragment", u.fragment)):
        m = _EMAIL_RE.search(text or "")
        if m:
            return (f"an email address ('{m.group(0)}') is built into the link's {where}; credential-phishing "
                    f"links often pre-fill the victim's address so the fake login page looks personalised")
    return None


def r19_combosquat(ctx: RuleContext) -> Optional[str]:
    u = ctx.url
    if u.is_ip or not u.domain:
        return None
    toks = _tokens(to_unicode_label(u.domain)) + [t for t in _tokens(u.subdomain) if len(t) > 3]
    for brand in ctx.brands:
        if brand.name in ctx.matched_brands or _official(brand, u.registrable):
            continue
        for t in toks:
            if t == brand.name and t != u.domain:
                ctx.matched_brands[brand.name] = "R19"
                return (f"the brand name '{brand.name}' is combined with other words in the domain "
                        f"'{u.registrable_unicode}', which is not a {brand.name} domain (combosquatting)")
            if (len(brand.name) >= 5 and len(t) >= 5 and t != brand.name
                    and Levenshtein.distance(t, brand.name) == 1):
                ctx.matched_brands[brand.name] = "R19"
                return (f"the word '{t}' in '{u.host_unicode}' is one letter away from the brand '{brand.name}', "
                        f"but the site is not a {brand.name} domain")
    return None


EXTENSION_RULES: list[RuleSpec] = [
    RuleSpec("R16", "Account-related keywords", "Lexical", 10,
             "Words like 'login', 'verify' or 'secure' in an address are used to make a fake page look like an official sign-in step.",
             "Real services rarely send you a link straight to a login page - go to the site yourself.", r16_sensitive_keyword),
    RuleSpec("R17", "Free or instant hosting platform", "Hosting", 10,
             "Free hosting and developer platforms let anyone publish a page in minutes, anonymously, under a respectable-looking shared domain.",
             "A bank or large company will not host its login page on a free platform.", r17_free_hosting),
    RuleSpec("R18", "Email address embedded in link", "Lexical", 15,
             "Phishing links often carry the victim's email address so the fake page can pre-fill it and look personalised.",
             "Be suspicious of a link that already 'knows' your email address.", r18_embedded_email),
    RuleSpec("R19", "Brand combined with other words (combosquatting)", "Typosquat", 18,
             "Attackers register names like 'brand-secure-login' that contain the real brand name but belong to someone else.",
             "Containing a brand's name does not make a domain belong to that brand.", r19_combosquat),
]

RULES = RULES + EXTENSION_RULES
CORE_RULE_IDS = [f"R{i:02d}" for i in range(1, 16)]
EXTENSION_RULE_IDS = [r.id for r in EXTENSION_RULES]
RULES_BY_ID = {r.id: r for r in RULES}
DEFAULT_WEIGHTS = {r.id: r.default_weight for r in RULES}
