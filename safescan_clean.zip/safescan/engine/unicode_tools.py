"""Unicode helpers for homograph detection (rules R08-R10).

Implements two mechanisms from Unicode Technical Standard #39:
  * script identification / mixed-script detection
  * the "skeleton" transform used to decide whether two strings are confusable

The confusables table (engine/data/confusables.txt) is the official UTS #39 data
file, bundled so the engine works without network access.
"""
from __future__ import annotations

import os
import unicodedata
from functools import lru_cache

_DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

# Script names are derived from the Unicode character name prefix. Python's
# standard library has no Script property, and the first word of the name is a
# reliable proxy for the scripts that matter for domain names.
_KNOWN_SCRIPTS = {
    "LATIN", "CYRILLIC", "GREEK", "ARMENIAN", "HEBREW", "ARABIC", "DEVANAGARI",
    "BENGALI", "THAI", "GEORGIAN", "HANGUL", "HIRAGANA", "KATAKANA", "CJK",
    "TAMIL", "TELUGU", "KANNADA", "MALAYALAM", "GUJARATI", "GURMUKHI", "ORIYA",
    "SINHALA", "LAO", "TIBETAN", "MYANMAR", "ETHIOPIC", "CHEROKEE", "KHMER",
    "MONGOLIAN", "BOPOMOFO", "COPTIC", "RUNIC", "OGHAM", "SYRIAC", "THAANA",
    "NKO", "VAI", "TIFINAGH", "MATHEMATICAL", "FULLWIDTH", "HALFWIDTH",
}

# Script combinations that UTS #39 ("Highly Restrictive") treats as legitimate.
_ALLOWED_COMBINATIONS = [
    {"LATIN", "HAN", "HIRAGANA", "KATAKANA"},  # Japanese
    {"LATIN", "HAN", "BOPOMOFO"},              # Chinese
    {"LATIN", "HAN", "HANGUL"},                # Korean
]


def char_script(ch: str) -> str:
    """Return an approximate Unicode script for a character.

    Digits, hyphen and other shared characters return "COMMON" so that they do
    not count towards mixing (UTS #39 treats Common/Inherited as neutral).
    """
    if ch.isascii():
        return "LATIN" if ch.isalpha() else "COMMON"
    cat = unicodedata.category(ch)
    if cat.startswith("M"):
        return "INHERITED"
    if cat.startswith("N") and not cat == "Nl":
        return "COMMON"
    try:
        name = unicodedata.name(ch)
    except ValueError:
        return "UNKNOWN"
    first = name.split(" ")[0]
    if first == "CJK":
        return "HAN"
    if first in ("FULLWIDTH", "HALFWIDTH", "MATHEMATICAL"):
        # Presentation forms of Latin letters - treated as a separate script so
        # that e.g. a fullwidth "ａ" mixed with ASCII is flagged.
        return first
    if first in _KNOWN_SCRIPTS:
        return first
    return first if cat.startswith("L") else "COMMON"


def scripts_in(label: str) -> set[str]:
    return {s for s in (char_script(c) for c in label) if s not in ("COMMON", "INHERITED")}


def is_mixed_script(label: str) -> tuple[bool, set[str]]:
    """True if the label mixes scripts in a way UTS #39 would not allow."""
    scripts = scripts_in(label)
    if len(scripts) <= 1:
        return False, scripts
    for allowed in _ALLOWED_COMBINATIONS:
        if scripts <= allowed:
            return False, scripts
    return True, scripts


@lru_cache(maxsize=1)
def _confusables() -> dict[str, str]:
    table: dict[str, str] = {}
    path = os.path.join(_DATA_DIR, "confusables.txt")
    with open(path, encoding="utf-8-sig") as fh:
        for line in fh:
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            parts = [p.strip() for p in line.split(";")]
            if len(parts) < 2:
                continue
            src = "".join(chr(int(cp, 16)) for cp in parts[0].split())
            dst = "".join(chr(int(cp, 16)) for cp in parts[1].split())
            table[src] = dst
    return table


def skeleton(text: str) -> str:
    """UTS #39 skeleton: NFD -> map each char via confusables -> NFD.

    The result is case-folded so brand comparisons are case-insensitive.
    Two strings are confusable when their skeletons are equal.
    """
    table = _confusables()
    s = unicodedata.normalize("NFD", text.casefold())
    s = "".join(table.get(c, c) for c in s)
    s = unicodedata.normalize("NFD", s)
    return s.casefold()


def to_unicode_label(label: str) -> str:
    """Decode a punycode (xn--) label to Unicode; return unchanged on failure."""
    if not label.lower().startswith("xn--"):
        return label
    try:
        return label[4:].encode("ascii").decode("punycode")
    except Exception:
        return label


def to_ascii_host(host: str) -> str:
    """Encode a Unicode host to its ASCII (punycode) form label by label."""
    out = []
    for label in host.split("."):
        if label.isascii():
            out.append(label.lower())
        else:
            try:
                out.append("xn--" + label.lower().encode("punycode").decode("ascii"))
            except Exception:
                out.append(label)
    return ".".join(out)
