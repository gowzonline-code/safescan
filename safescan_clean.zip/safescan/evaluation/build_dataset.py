"""Build the labelled evaluation dataset (proposal Section 3.1.5).

Inputs (any of):
  --phish   text file with one URL per line, OR a PhishTank CSV (column 'url')
  --benign  ranked domain list, one per line, OR a Tranco CSV ('rank,domain')
  --recent  optional list of the most recently reported phishing URLs

Cleaning steps (all recorded in dataset_stats.json):
  1. drop lines that fail SafeScan's own URL validation
  2. drop URL-shortener hosts (their destination cannot be known without visiting)
  3. keep one URL per registrable domain (removes near-identical campaign variants)
  4. remove any registrable domain that appears in both classes
  5. sample 1,000 per class; benign = 250 homepages from the top 10k + 250 from
     ranks 10k-1M + 500 deep-link URLs (paths/queries) from --benign-urls
     (deviation from the proposal, see report Section 7.5: homepages alone made
     the negative class structurally trivial)
  6. stratified 40% refinement / 60% held-out split

No URL is ever visited. Usage:
  python -m evaluation.build_dataset --phish data_raw/phish_active.txt --benign data_raw/top1m.txt
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.parser import URLValidationError, parse_url  # noqa: E402

SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "cutt.ly", "rb.gy",
    "rebrand.ly", "shorturl.at", "tiny.cc", "s.id", "v.gd", "bitly.com", "t.ly", "shorturl.asia",
    "qrco.de", "lnkd.in", "urlz.fr", "surl.li", "u.to", "clck.ru",
}
SEED = 42
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def read_phish(path: str) -> list[str]:
    with open(path, encoding="utf-8", errors="ignore") as fh:
        head = fh.readline()
        fh.seek(0)
        if "url" in head.lower() and "," in head:
            return [row["url"] for row in csv.DictReader(fh) if row.get("url")]
        return [l.strip() for l in fh if l.strip() and not l.startswith("#")]


def read_ranked_domains(path: str) -> list[str]:
    out = []
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            out.append(line.split(",")[-1])   # works for 'domain' and 'rank,domain'
    return out


def clean(urls, label, stats):
    seen, kept = set(), []
    for u in urls:
        try:
            p = parse_url(u)
        except URLValidationError:
            stats[label]["invalid"] += 1
            continue
        if p.registrable in SHORTENERS:
            stats[label]["shortener"] += 1
            continue
        if p.registrable in seen:
            stats[label]["duplicate_registrable"] += 1
            continue
        seen.add(p.registrable)
        kept.append((u, p.registrable))
    return kept


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--phish", required=True)
    ap.add_argument("--benign", required=True)
    ap.add_argument("--benign-urls", help="CSV with url,label where label=='good' rows are benign deep links")
    ap.add_argument("--recent")
    ap.add_argument("--n", type=int, default=1000)
    args = ap.parse_args(argv)
    rng = random.Random(SEED)
    stats = {c: {"input": 0, "invalid": 0, "shortener": 0, "duplicate_registrable": 0, "overlap_removed": 0}
             for c in ("phishing", "benign")}

    phish_raw = read_phish(args.phish)
    stats["phishing"]["input"] = len(phish_raw)
    rng.shuffle(phish_raw)
    # cleaning a 1M-line file is unnecessary: oversample a generous pool first
    phish = clean(phish_raw[: args.n * 30], "phishing", stats)

    ranked = read_ranked_domains(args.benign)
    stats["benign"]["input"] = len(ranked)
    head = ranked[:10_000]
    tail = ranked[10_000:]
    head_pool = rng.sample(head, min(len(head), args.n * 2))
    tail_pool = rng.sample(tail, min(len(tail), args.n * 2))
    benign_head = clean(["https://" + d + "/" for d in head_pool], "benign", stats)
    benign_tail = clean(["https://" + d + "/" for d in tail_pool], "benign", stats)
    benign_deep = []
    if args.benign_urls:
        with open(args.benign_urls, encoding="utf-8", errors="ignore") as fh:
            good = [r["url"].strip() for r in csv.DictReader(fh) if r.get("label") == "good"]
        stats["benign"]["input_deep_links"] = len(good)
        # keep only genuine deep links (something after the host)
        good = [g for g in good if "/" in g.split("://")[-1].rstrip("/")]
        rng.shuffle(good)
        good = ["https://" + g if "://" not in g else g for g in good[: args.n * 4]]
        benign_deep = clean(good, "benign", stats)

    phish_regs = {r for _, r in phish}
    benign_regs = {r for _, r in benign_head + benign_tail + benign_deep}
    overlap = phish_regs & benign_regs
    phish = [(u, r) for u, r in phish if r not in overlap]
    benign_head = [(u, r) for u, r in benign_head if r not in overlap]
    benign_tail = [(u, r) for u, r in benign_tail if r not in overlap]
    # a registrable domain may appear in only one benign stratum
    used = {r for _, r in benign_head + benign_tail}
    benign_deep = [(u, r) for u, r in benign_deep if r not in overlap and r not in used]
    stats["phishing"]["overlap_removed"] = stats["benign"]["overlap_removed"] = len(overlap)

    phish_s = phish[: args.n]
    if benign_deep:
        q = args.n // 4
        benign_s = ([(u, r, "head") for u, r in benign_head[:q]] + [(u, r, "tail") for u, r in benign_tail[:q]]
                    + [(u, r, "deeplink") for u, r in benign_deep[: args.n - 2 * q]])
    else:
        half = args.n // 2
        benign_s = [(u, r, "head") for u, r in benign_head[:half]] + [(u, r, "tail") for u, r in benign_tail[: args.n - half]]

    rows = [{"url": u, "label": 1, "registrable": r, "stratum": "phishing"} for u, r in phish_s]
    rows += [{"url": u, "label": 0, "registrable": r, "stratum": s} for u, r, s in benign_s]

    # stratified 40/60 split
    for lab in (0, 1):
        idx = [i for i, row in enumerate(rows) if row["label"] == lab]
        rng.shuffle(idx)
        cut = int(len(idx) * 0.4)
        for k, i in enumerate(idx):
            rows[i]["split"] = "refine" if k < cut else "holdout"

    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "dataset.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["url", "label", "registrable", "stratum", "split"])
        w.writeheader()
        w.writerows(rows)

    if args.recent:
        rstats = {"phishing_recent": {"input": 0, "invalid": 0, "shortener": 0, "duplicate_registrable": 0}}
        rr = read_phish(args.recent)
        rstats["phishing_recent"]["input"] = len(rr)
        recent = clean(rr, "phishing_recent", rstats)
        with open(os.path.join(OUT, "recent.csv"), "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=["url", "label", "registrable"])
            w.writeheader()
            w.writerows({"url": u, "label": 1, "registrable": r} for u, r in recent)
        stats.update(rstats)
        stats["phishing_recent"]["kept"] = len(recent)

    stats["final"] = {
        "phishing": len(phish_s), "benign": len(benign_s),
        "benign_head": sum(1 for b in benign_s if b[2] == "head"),
        "benign_tail": sum(1 for b in benign_s if b[2] == "tail"),
        "benign_deeplink": sum(1 for b in benign_s if b[2] == "deeplink"),
        "refine": sum(1 for r in rows if r["split"] == "refine"),
        "holdout": sum(1 for r in rows if r["split"] == "holdout"),
        "seed": SEED,
    }
    with open(os.path.join(OUT, "dataset_stats.json"), "w") as fh:
        json.dump(stats, fh, indent=2)
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
