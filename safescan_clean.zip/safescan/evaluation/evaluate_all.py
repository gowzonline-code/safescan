"""Final evaluation on the FROZEN weights (run after refine.py). Produces every
number and figure used in Chapter 7 of the report.

  python -m evaluation.refine          # 40% split -> frozen weights/bands
  python -m evaluation.evaluate_all    # 60% held-out split, recent set, figures
"""
from __future__ import annotations

import csv
import json
import os
import random
import re
import statistics
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import Levenshtein  # noqa: E402
from engine import DEFAULT_WEIGHTS, analyse, load_default_brands  # noqa: E402
from engine.rules import DEFAULT_HIGH_RISK_TLDS, FREE_HOSTING_SUFFIXES  # noqa: E402
from evaluation.run_eval import (V1_RULES, V2_RULES, load_rows, metrics, restrict,  # noqa: E402
                                 rule_rates, scan_rows, score_with)

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
FIG = os.path.join(HERE, "figures")
PHISH, BENIGN = "#eb6834", "#2a78d6"   # validated categorical slots 2 and 1
INK, MUTED, GRID = "#1f1f1e", "#6b6a63", "#e6e5df"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": MUTED, "axes.labelcolor": INK,
    "xtick.color": MUTED, "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True,
    "figure.dpi": 160, "savefig.bbox": "tight",
})


def load(name):
    return json.load(open(os.path.join(RES, name)))


def per_stratum(records):
    out = {}
    for s in ("head", "tail", "deeplink"):
        sub = [r for r in records if r["stratum"] == s]
        fp = sum(1 for r in sub if r["band"] != "safe")
        out[s] = {"n": len(sub), "fp": fp, "fpr": round(fp / len(sub), 4) if sub else 0}
    return out


# ------------------------------------------------------------ explanation checks

def _syllables(word):
    word = word.lower()
    groups = re.findall(r"[aeiouy]+", word)
    n = len(groups) - (1 if word.endswith("e") and len(groups) > 1 else 0)
    return max(1, n)


def flesch(text):
    sents = max(1, len(re.findall(r"[.!?]+", text)))
    words = re.findall(r"[A-Za-z]+", text)
    if not words:
        return 0.0
    syl = sum(_syllables(w) for w in words)
    return round(206.835 - 1.015 * (len(words) / sents) - 84.6 * (syl / len(words)), 1)


def verify_finding(rule_id, url, parsed):
    """Independent re-derivation of each rule's factual claim, written separately
    from the rule code, to test explanation criterion (1) 'factually valid'."""
    host = parsed["host"]
    if rule_id == "R04":
        return len(parsed["normalised"]) > 75
    if rule_id == "R01":
        return bool(re.fullmatch(r"[\d.]+|\[?[0-9a-f:]+\]?|0x[0-9a-f]+", host))
    if rule_id == "R07":
        return host.rsplit(".", 1)[-1] in DEFAULT_HIGH_RISK_TLDS
    if rule_id == "R05":
        return host.rsplit(".", 1)[0].count("-") > 3 or parsed["host_unicode"].count("-") > 3
    if rule_id == "R06":
        core = re.sub(r"[^a-z0-9]", "", parsed["host_unicode"].rsplit(".", 1)[0].lower())
        return bool(core) and sum(c.isdigit() for c in core) / len(core) > 0.25
    if rule_id in ("R12", "R19", "R11", "R10"):
        reg = parsed["registrable_domain"]
        names = [b.name for b in load_default_brands()]
        hit = [n for n in names if n in url.lower() or Levenshtein.distance(parsed["host"].split(".")[0], n) <= 2]
        return bool(hit) and not any(reg.endswith(d) for b in load_default_brands() if b.name in hit for d in b.domains)
    if rule_id == "R16":
        return bool(re.search(r"login|signin|secure|account|verif|password|wallet|update|confirm|auth|bank|billing|recover|unlock|suspend|validation|logon|sso|webscr|passwd",
                              url.lower()))
    if rule_id == "R17":
        return any(host == x or host.endswith("." + x) for x in FREE_HOSTING_SUFFIXES)
    if rule_id == "R18":
        return "@" in url or "%40" in url.lower()
    return True


def main():
    os.makedirs(FIG, exist_ok=True)
    brands = load_default_brands()
    rows = load_rows(os.path.join(HERE, "data", "dataset.csv"), "holdout")
    raw = scan_rows(rows, DEFAULT_WEIGHTS, brands=brands)

    configs = {
        "v1_initial": (V1_RULES, load("weights_initial.json"), {"suspicious": 30, "dangerous": 60}),
        "v1_refined": (V1_RULES, load("weights_v1_refined.json"), load("bands_v1_refined.json")),
        "v2_refined": (V2_RULES, load("weights_v2_refined.json"), load("bands_v2_refined.json")),
    }
    results = {"holdout": {}, "recent": {}, "per_stratum": {}, "sensitivity": {}}
    scored = {}
    for name, (ids, w, b) in configs.items():
        recs = score_with(restrict(raw, ids), w, b)
        scored[name] = recs
        results["holdout"][name] = metrics(recs)
        results["per_stratum"][name] = per_stratum(recs)
    results["rule_rates_holdout"] = rule_rates(restrict(raw, V2_RULES), V2_RULES)

    # threshold sensitivity (v1_refined and v2_refined)
    for name in ("v1_refined", "v2_refined"):
        ids, w, b = configs[name]
        base = restrict(raw, ids)
        sens = []
        for t in range(5, 61, 1):
            m = metrics(score_with(base, w, {"suspicious": t, "dangerous": max(t + 1, b["dangerous"])}))
            sens.append({"threshold": t, **{k: m[k] for k in ("precision", "recall", "f1", "fpr")}})
        results["sensitivity"][name] = sens

    # recently reported phishing (OpenPhish public feed, newest 300 entries)
    recent_path = os.path.join(HERE, "data", "recent.csv")
    if os.path.exists(recent_path):
        rrows = load_rows(recent_path)
        rraw = scan_rows(rrows, DEFAULT_WEIGHTS, brands=brands)
        for name, (ids, w, b) in configs.items():
            recs = score_with(restrict(rraw, ids), w, b)
            det = sum(1 for r in recs if r["band"] != "safe")
            results["recent"][name] = {"n": len(recs), "detected": det, "recall": round(det / len(recs), 4)}

    # latency (full analyse() call incl. parsing, offline)
    times = [r["ms"] for r in raw]
    results["latency_ms"] = {"mean": round(statistics.mean(times), 3), "median": round(statistics.median(times), 3),
                             "p95": round(sorted(times)[int(0.95 * len(times))], 3), "max": round(max(times), 3)}

    # explanation quality (Section 3.7.4) on a stratified sample of 40 outputs
    w2, b2 = configs["v2_refined"][1], configs["v2_refined"][2]
    v2 = scored["v2_refined"]
    rng = random.Random(3)
    pools = {"TP": [r for r in v2 if r["label"] == 1 and r["band"] != "safe"],
             "FP": [r for r in v2 if r["label"] == 0 and r["band"] != "safe"],
             "FN_with_findings": [r for r in v2 if r["label"] == 1 and r["band"] == "safe" and r["fired"]],
             "TN": [r for r in v2 if r["label"] == 0 and r["band"] == "safe"]}
    quota = {"TP": 20, "FP": 10, "FN_with_findings": 5, "TN": 5}
    sample = []
    for k, q in quota.items():
        pool = pools[k][:]
        rng.shuffle(pool)
        sample += [(k, r) for r in pool[:q]]
    expl_rows = []
    valid_checks = total_checks = consistent = 0
    readabilities = []
    for kind, r in sample:
        res = analyse(r["url"], weights=w2, bands=b2, brands=brands,
                      enabled=V2_RULES)
        score_sum = min(100, sum(f.weight for f in res.findings))
        cons = score_sum == res.score
        consistent += cons
        for f in res.findings:
            ok = verify_finding(f.rule_id, r["url"], res.parsed)
            valid_checks += ok
            total_checks += 1
            text = f.evidence + ". " + f.rationale
            readabilities.append(flesch(text))
        expl_rows.append({"outcome": kind, "url": r["url"], "score": res.score, "band": res.band,
                          "findings": " | ".join(f"{f.rule_id} (+{f.weight}): {f.evidence}" for f in res.findings),
                          "summary": res.summary, "consistent_with_score": cons,
                          "criterion1_valid(auto)": "", "criterion2_comprehensible(rate 1-3)": "",
                          "criterion3_accounts_for_score": cons})
    with open(os.path.join(RES, "explanation_rubric_sample.csv"), "w", newline="", encoding="utf-8") as fh:
        wr = csv.DictWriter(fh, fieldnames=list(expl_rows[0].keys()))
        wr.writeheader()
        wr.writerows(expl_rows)
    results["explanations"] = {
        "sample_size": len(sample), "findings_checked": total_checks,
        "factually_valid_auto": valid_checks, "score_consistent": consistent,
        "flesch_mean": round(statistics.mean(readabilities), 1) if readabilities else None,
        "flesch_median": round(statistics.median(readabilities), 1) if readabilities else None,
    }

    # false-negative categorisation (v2) for the error analysis
    def category(r):
        u = r["url"].lower()
        host = r["dest"]
        if any(x in u for x in ("pages.dev", "workers.dev", "netlify", "vercel", "web.app", "firebase", "github.io",
                                 "appspot", "webflow", "repl.", "weebly", "wix", "blogspot", "r2.dev", "glitch")):
            return "free hosting (unlisted or no other signal)"
        if re.search(r"/wp-(content|includes|admin)/", u):
            return "compromised CMS site (wp- path)"
        if re.search(r"\.(php|html?|aspx?)(\?|$)", u):
            return "page on unremarkable domain"
        if r["url"].rstrip("/").count("/") <= 2:
            return "bare domain, no lexical signal"
        return "other"
    fns = [r for r in v2 if r["label"] == 1 and r["band"] == "safe"]
    cats = {}
    for r in fns:
        c = category(r)
        cats[c] = cats.get(c, 0) + 1
    results["fn_categories_v2"] = dict(sorted(cats.items(), key=lambda x: -x[1]))
    results["fp_examples_v2"] = [{"url": r["url"], "stratum": r["stratum"], "fired": r["fired"], "score": r["score"]}
                                 for r in v2 if r["label"] == 0 and r["band"] != "safe"]
    results["fn_examples_v2"] = [r["url"] for r in fns[:25]]

    json.dump(results, open(os.path.join(RES, "evaluation_results.json"), "w"), indent=2)

    # ------------------------------------------------------------- figures
    # Fig: confusion matrices
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.3))
    titles = {"v1_initial": "Rule set v1, proposal weights", "v1_refined": "Rule set v1, refined",
              "v2_refined": "Rule set v2, refined"}
    for ax, name in zip(axes, configs):
        m = results["holdout"][name]
        grid = [[m["tn"], m["fp"]], [m["fn"], m["tp"]]]
        ax.imshow([[0, 1], [1, 0]], cmap=matplotlib.colors.ListedColormap(["#eef4fc", "#fbe9e1"]))
        for i in range(2):
            for j in range(2):
                ax.text(j, i, str(grid[i][j]), ha="center", va="center", fontsize=14, color=INK)
        ax.set_xticks([0, 1], ["Predicted safe", "Predicted\nsuspicious/dangerous"], fontsize=8)
        ax.set_yticks([0, 1], ["Benign", "Phishing"], fontsize=8)
        ax.grid(False)
        ax.set_title(f"{titles[name]}\nP={m['precision']:.3f}  R={m['recall']:.3f}  F1={m['f1']:.3f}", fontsize=9)
    fig.savefig(os.path.join(FIG, "fig_confusion_matrices.png"))
    plt.close(fig)

    # Fig: score distribution v2
    fig, ax = plt.subplots(figsize=(7, 3.4))
    bins = list(range(0, 105, 5))
    ax.hist([r["score"] for r in v2 if r["label"] == 0], bins=bins, color=BENIGN, label="Benign",
            edgecolor="white", linewidth=1.5)
    ax.hist([r["score"] for r in v2 if r["label"] == 1], bins=bins, color=PHISH, alpha=0.85, label="Phishing",
            edgecolor="white", linewidth=1.5)
    for t, lab in ((b2["suspicious"], "suspicious"), (b2["dangerous"], "dangerous")):
        ax.axvline(t, color=INK, linewidth=1, linestyle="--")
        ax.text(t + 1, ax.get_ylim()[1] * 0.92, lab, fontsize=8, color=INK)
    ax.set_yscale("log")
    ax.set_xlabel("SafeScan score (rule set v2, refined weights)")
    ax.set_ylabel("URLs (log scale)")
    ax.legend(frameon=False)
    fig.savefig(os.path.join(FIG, "fig_score_distribution.png"))
    plt.close(fig)

    # Fig: rule firing rates on held-out
    rr = results["rule_rates_holdout"]
    ids = [k for k in V2_RULES if rr[k]["phish_fired"] + rr[k]["benign_fired"] > 0]
    fig, ax = plt.subplots(figsize=(8, 3.6))
    x = range(len(ids))
    ax.bar([i - 0.2 for i in x], [rr[k]["phish_rate"] * 100 for k in ids], width=0.38, color=PHISH, label="Phishing")
    ax.bar([i + 0.2 for i in x], [rr[k]["benign_rate"] * 100 for k in ids], width=0.38, color=BENIGN, label="Benign")
    ax.set_xticks(list(x), ids)
    ax.set_ylabel("% of URLs where rule fired")
    ax.legend(frameon=False)
    fig.savefig(os.path.join(FIG, "fig_rule_firing_rates.png"))
    plt.close(fig)

    # Fig: threshold sensitivity v2
    sens = results["sensitivity"]["v2_refined"]
    fig, ax = plt.subplots(figsize=(7, 3.4))
    t = [s["threshold"] for s in sens]
    ax.plot(t, [s["precision"] for s in sens], color=BENIGN, linewidth=2, label="Precision")
    ax.plot(t, [s["recall"] for s in sens], color=PHISH, linewidth=2, label="Recall")
    ax.plot(t, [s["f1"] for s in sens], color="#1baf7a", linewidth=2, label="F1")
    ax.axvline(b2["suspicious"], color=INK, linewidth=1, linestyle="--")
    ax.text(b2["suspicious"] + 0.8, 0.05, "frozen threshold", fontsize=8)
    ax.set_xlabel("'Suspicious' band threshold (score)")
    ax.set_ylim(0, 1.02)
    ax.legend(frameon=False, loc="center right")
    fig.savefig(os.path.join(FIG, "fig_threshold_sensitivity.png"))
    plt.close(fig)

    print(json.dumps({k: results[k] for k in ("holdout", "per_stratum", "recent", "latency_ms", "explanations",
                                              "fn_categories_v2")}, indent=2))
    print("FP:", results["fp_examples_v2"])


if __name__ == "__main__":
    main()
