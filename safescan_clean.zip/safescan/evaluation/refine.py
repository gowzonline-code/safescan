"""Empirical heuristic calibration (proposal Section 3.7.3).

Uses ONLY the 40% refinement split. Steps, all deterministic and recorded:

 1. Firing rates. For each rule, the firing rate in the phishing (p) and benign
    (b) classes, and a discrimination ratio d = (p + a) / (p + b + 2a) with
    Laplace smoothing a = 0.005 so that rules which never fire stay at 0.5.
 2. Weight adjustment. Rules with fewer than MIN_FIRES total firings keep their
    initial weight (insufficient evidence). Otherwise the weight is multiplied:
        d >= 0.95 -> x1.50   (fires almost only on phishing: raise)
        d >= 0.85 -> x1.25
        d >= 0.60 -> x1.00
        d >= 0.40 -> x0.50   (fires on both classes: lower)
        else      -> x0.25
    and capped at MAX_WEIGHT.
 3. Double counting. Pairwise phi correlation between rule firings on the
    phishing class; where phi > 0.6 the lower-weighted rule of the pair is
    halved.
 4. Band thresholds. The 'suspicious' threshold is the score that maximises F1
    on the refinement split subject to a false-positive rate <= 5% (precision
    is prioritised, Section 3.7.1). The 'dangerous' threshold is the lowest
    score >= suspicious + 10 at which refinement precision is >= 0.98.

Outputs evaluation/results/weights_refined.json and bands_refined.json, which
are then FROZEN before the held-out split is scored by evaluate_all.py.
"""
from __future__ import annotations

import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine import DEFAULT_WEIGHTS, RULES  # noqa: E402
from evaluation.run_eval import (OFFLINE_RULES, V1_RULES, V2_RULES, load_rows, metrics, restrict,  # noqa: E402
                                 rule_rates, scan_rows, score_with)

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
MIN_FIRES = 5
MAX_WEIGHT = 40
ALPHA = 0.005
MAX_FPR = 0.05


def multiplier(d: float) -> float:
    if d >= 0.95:
        return 1.5
    if d >= 0.85:
        return 1.25
    if d >= 0.60:
        return 1.0
    if d >= 0.40:
        return 0.5
    return 0.25


def phi(records, a, b):
    n11 = sum(1 for r in records if a in r["fired"] and b in r["fired"])
    n10 = sum(1 for r in records if a in r["fired"] and b not in r["fired"])
    n01 = sum(1 for r in records if a not in r["fired"] and b in r["fired"])
    n00 = len(records) - n11 - n10 - n01
    den = math.sqrt((n11 + n10) * (n01 + n00) * (n11 + n01) * (n10 + n00))
    return (n11 * n00 - n10 * n01) / den if den else 0.0


def choose_bands(records, weights):
    best = None
    for t in range(5, 101):
        m = metrics(score_with(records, weights, {"suspicious": t, "dangerous": 101}))
        if m["fpr"] <= MAX_FPR and (best is None or m["f1"] > best[1]["f1"]):
            best = (t, m)
    sus = best[0]
    dang = None
    for t in range(sus + 10, 101):
        sub = [r for r in score_with(records, weights, {"suspicious": t, "dangerous": 101})
               if r["band"] != "safe"]
        if len(sub) >= 10:
            prec = sum(r["label"] for r in sub) / len(sub)
            if prec >= 0.98:
                dang = t
                break
    return {"suspicious": sus, "dangerous": dang or min(100, sus + 30)}, best[1]


def calibrate(recs, rule_ids, initial):
    """Apply steps 1-4 to scanned refinement records. Returns weights, bands, log."""
    recs = restrict(recs, rule_ids)
    rates = rule_rates(recs, rule_ids)
    log = {"rule_ids": rule_ids, "initial_weights": {k: initial[k] for k in rule_ids}, "rates": rates, "steps": []}
    weights = {k: initial[k] for k in rule_ids}
    for rid in rule_ids:
        r = rates[rid]
        total = r["phish_fired"] + r["benign_fired"]
        d = (r["phish_rate"] + ALPHA) / (r["phish_rate"] + r["benign_rate"] + 2 * ALPHA)
        r["discrimination"] = round(d, 3)
        if total < MIN_FIRES:
            log["steps"].append({"rule": rid, "action": "kept (insufficient firings)", "fires": total,
                                 "from": weights[rid], "to": weights[rid]})
            continue
        m = multiplier(d)
        new = int(min(MAX_WEIGHT, round(weights[rid] * m)))
        log["steps"].append({"rule": rid, "d": round(d, 3), "multiplier": m, "from": weights[rid], "to": new})
        weights[rid] = new

    pos = [r for r in recs if r["label"] == 1]
    corr = []
    for i, a in enumerate(rule_ids):
        for b in rule_ids[i + 1:]:
            v = phi(pos, a, b)
            if abs(v) > 0.3:
                corr.append({"a": a, "b": b, "phi": round(v, 3)})
            if v > 0.6:
                lo = a if weights[a] <= weights[b] else b
                old = weights[lo]
                weights[lo] = max(1, round(old / 2))
                log["steps"].append({"rule": lo, "action": f"halved for correlation with {b if lo == a else a}",
                                     "phi": round(v, 3), "from": old, "to": weights[lo]})
    log["correlations"] = corr
    bands, _ = choose_bands(recs, weights)
    log["bands"] = bands
    log["refine_metrics_initial"] = metrics(score_with(recs, initial, {"suspicious": 30, "dangerous": 60}))
    log["refine_metrics_refined"] = metrics(score_with(recs, weights, bands))
    log["refined_weights"] = dict(weights)
    return weights, bands, log


def main():
    os.makedirs(RES, exist_ok=True)
    rows = load_rows(os.path.join(HERE, "data", "dataset.csv"), "refine")
    recs = scan_rows(rows, DEFAULT_WEIGHTS)
    out = {}
    for name, ids in (("v1", V1_RULES), ("v2", V2_RULES)):
        w, b, log = calibrate(recs, ids, DEFAULT_WEIGHTS)
        full = dict(w)
        for r in RULES:              # network rules (R13-R15) keep initial weights;
            full.setdefault(r.id, 0 if r.id not in ids and not r.requires_network else r.default_weight)
        json.dump(full, open(os.path.join(RES, f"weights_{name}_refined.json"), "w"), indent=2)
        json.dump(b, open(os.path.join(RES, f"bands_{name}_refined.json"), "w"), indent=2)
        json.dump(log, open(os.path.join(RES, f"refinement_log_{name}.json"), "w"), indent=2)
        out[name] = {k: log[k] for k in ("steps", "correlations", "bands", "refine_metrics_initial", "refine_metrics_refined")}
    json.dump(dict(DEFAULT_WEIGHTS), open(os.path.join(RES, "weights_initial.json"), "w"), indent=2)
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
