"""Batch evaluation harness (proposal Section 3.7).

Runs the SafeScan engine - with no network access - over a labelled CSV and
reports the confusion matrix, accuracy, precision, recall and F1. A URL is a
positive detection when its band is 'suspicious' or 'dangerous'.

Usage:
  python -m evaluation.run_eval --weights evaluation/results/weights_initial.json --split holdout
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine import DEFAULT_BANDS, DEFAULT_WEIGHTS, RULES, analyse, load_default_brands  # noqa: E402
from engine.parser import URLValidationError  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
OFFLINE_RULES = [r.id for r in RULES if not r.requires_network]
V1_RULES = [r for r in OFFLINE_RULES if int(r[1:]) <= 15]      # proposal rule set (Table 3-3)
V2_RULES = list(OFFLINE_RULES)                                  # + extension rules R16-R19


def restrict(records, rule_ids):
    """Drop firings of rules outside rule_ids (the engine is deterministic and the
    extension rules run after R10-R12, so this equals scanning with only rule_ids)."""
    keep = set(rule_ids)
    return [{**r, "fired": [x for x in r["fired"] if x in keep]} for r in records]


def load_rows(path, split=None):
    with open(path, encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    for r in rows:
        r["label"] = int(r["label"])
    if split and split != "all":
        rows = [r for r in rows if r.get("split") == split]
    return rows


def scan_rows(rows, weights, bands=None, brands=None):
    """Return one record per row: score, band, fired rule ids, timing."""
    brands = brands or load_default_brands()
    out = []
    for r in rows:
        try:
            res = analyse(r["url"], weights=weights, enabled=OFFLINE_RULES, brands=brands, bands=bands)
            fired = [f.rule_id for f in res.findings]
            out.append({**r, "score": res.score, "band": res.band, "fired": fired,
                        "ms": res.duration_ms, "dest": res.true_destination})
        except URLValidationError as exc:
            out.append({**r, "score": 0, "band": "invalid", "fired": [], "ms": 0, "dest": "", "error": str(exc)})
    return out


def score_with(records, weights, bands):
    """Re-score already-scanned records with new weights (rules are deterministic)."""
    out = []
    for r in records:
        s = min(100, sum(int(weights.get(rid, 0)) for rid in r["fired"]))
        band = "dangerous" if s >= bands["dangerous"] else "suspicious" if s >= bands["suspicious"] else "safe"
        out.append({**r, "score": s, "band": band})
    return out


def metrics(records):
    tp = sum(1 for r in records if r["label"] == 1 and r["band"] in ("suspicious", "dangerous"))
    fn = sum(1 for r in records if r["label"] == 1 and r["band"] not in ("suspicious", "dangerous"))
    fp = sum(1 for r in records if r["label"] == 0 and r["band"] in ("suspicious", "dangerous"))
    tn = sum(1 for r in records if r["label"] == 0 and r["band"] not in ("suspicious", "dangerous"))
    n = tp + fn + fp + tn
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {
        "n": n, "tp": tp, "fn": fn, "fp": fp, "tn": tn,
        "accuracy": round((tp + tn) / n, 4) if n else 0.0,
        "precision": round(precision, 4), "recall": round(recall, 4), "f1": round(f1, 4),
        "fpr": round(fp / (fp + tn), 4) if fp + tn else 0.0,
        "bands": dict(Counter(f"{'phish' if r['label'] else 'benign'}:{r['band']}" for r in records)),
    }


def rule_rates(records, rule_ids=None):
    rule_ids = rule_ids or OFFLINE_RULES
    pos = [r for r in records if r["label"] == 1]
    neg = [r for r in records if r["label"] == 0]
    rates = {}
    for rid in rule_ids:
        p = sum(rid in r["fired"] for r in pos)
        b = sum(rid in r["fired"] for r in neg)
        rates[rid] = {"phish_fired": p, "benign_fired": b,
                      "phish_rate": round(p / len(pos), 4) if pos else 0,
                      "benign_rate": round(b / len(neg), 4) if neg else 0}
    return rates


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=os.path.join(HERE, "data", "dataset.csv"))
    ap.add_argument("--split", default="holdout")
    ap.add_argument("--weights")
    ap.add_argument("--bands")
    args = ap.parse_args(argv)
    weights = json.load(open(args.weights)) if args.weights else DEFAULT_WEIGHTS
    bands = json.load(open(args.bands)) if args.bands else DEFAULT_BANDS
    recs = scan_rows(load_rows(args.data, args.split), weights, bands)
    print(json.dumps({"metrics": metrics(recs), "rule_rates": rule_rates(recs)}, indent=2))


if __name__ == "__main__":
    main()
