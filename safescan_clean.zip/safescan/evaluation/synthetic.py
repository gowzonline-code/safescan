"""Synthetic capability test for the character-level rules (R08-R12, R19).

Homograph attacks are rare in live feeds (Holgers et al., 2006), so the
held-out sample cannot exercise R08-R10. This script generates labelled attack
variants of every brand in the brand list, plus controls (the brands' own
official domains), and reports per-technique detection. The URLs are synthetic
strings; none is resolved or visited.
"""
from __future__ import annotations

import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine import analyse, load_default_brands  # noqa: E402

CYRILLIC = {"a": "а", "e": "е", "o": "о", "p": "р", "c": "с", "x": "х",
            "y": "у", "i": "і", "s": "ѕ", "j": "ј"}
DIGITS = {"o": "0", "l": "1", "i": "1", "e": "3", "a": "4", "s": "5"}
SEED = 7


def variants(brand: str, rng: random.Random) -> dict[str, str]:
    out = {}
    # homograph: replace one Latin letter with a Cyrillic look-alike (mixed script)
    idx = [i for i, ch in enumerate(brand) if ch in CYRILLIC]
    if idx:
        i = rng.choice(idx)
        out["homograph_mixed"] = brand[:i] + CYRILLIC[brand[i]] + brand[i + 1:]
    # whole-script homograph: every letter Cyrillic (only possible for some brands)
    if all(ch in CYRILLIC for ch in brand):
        out["homograph_whole_script"] = "".join(CYRILLIC[c] for c in brand)
    idx = [i for i, ch in enumerate(brand) if ch in DIGITS]
    if idx:
        i = rng.choice(idx)
        out["digit_substitution"] = brand[:i] + DIGITS[brand[i]] + brand[i + 1:]
    if len(brand) >= 4:
        i = rng.randrange(1, len(brand))
        out["typo_insertion"] = brand[:i] + brand[i - 1] + brand[i:]          # doubled letter
        i = rng.randrange(1, len(brand) - 1)
        out["typo_omission"] = brand[:i] + brand[i + 1:]
        i = rng.randrange(0, len(brand) - 1)
        out["typo_transposition"] = brand[:i] + brand[i + 1] + brand[i] + brand[i + 2:]
    out["combosquat"] = f"{brand}-secure-login"
    out["brand_in_subdomain"] = f"{brand}.com.account-verify"
    return out


def main():
    rng = random.Random(SEED)
    brands = load_default_brands()
    rows = []
    for b in brands:
        for tech, label in variants(b.name, rng).items():
            if tech == "brand_in_subdomain":
                url = f"https://{label}.example-host.net/"
            else:
                url = f"https://{label}.com/"
            rows.append((tech, b.name, url, 1))
        for d in b.domains[:2]:
            rows.append(("control_official_domain", b.name, f"https://{d}/", 0))
    w = json.load(open(os.path.join(os.path.dirname(__file__), "results", "weights_v2_refined.json")))
    bands = json.load(open(os.path.join(os.path.dirname(__file__), "results", "bands_v2_refined.json")))
    summary = {}
    examples = []
    for tech, brand, url, lab in rows:
        res = analyse(url, weights=w, bands=bands, brands=brands)
        fired = [f.rule_id for f in res.findings]
        flagged = res.band != "safe"
        s = summary.setdefault(tech, {"n": 0, "flagged": 0, "rules": {}})
        s["n"] += 1
        s["flagged"] += int(flagged)
        for r in fired:
            s["rules"][r] = s["rules"].get(r, 0) + 1
        if len(examples) < 400:
            examples.append({"technique": tech, "brand": brand, "url": url, "display": res.parsed["host_unicode"],
                             "score": res.score, "band": res.band, "fired": fired})
    for s in summary.values():
        s["rate"] = round(s["flagged"] / s["n"], 3)
    out = os.path.join(os.path.dirname(__file__), "results")
    json.dump({"summary": summary, "examples": examples}, open(os.path.join(out, "synthetic_results.json"), "w"),
              indent=2, ensure_ascii=False)
    for k, v in summary.items():
        print(f"{k:28s} n={v['n']:3d} flagged={v['rate']:.0%} rules={v['rules']}")


if __name__ == "__main__":
    main()
