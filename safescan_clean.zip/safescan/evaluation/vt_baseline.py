"""Baseline comparison with VirusTotal (proposal Section 3.7.2).

YOU must run this - it needs a free VirusTotal API key and internet access:

    set VT_API_KEY=your_key            (Windows)   |   export VT_API_KEY=your_key   (macOS/Linux)
    python -m evaluation.vt_baseline --n 150 --recent 50

The free public API allows 4 requests/minute and 500/day, so 200 URLs takes
about 50 minutes. The script resumes where it stopped (results are appended to
evaluation/results/vt_raw.csv), so it is safe to interrupt and re-run.

Only EXISTING VirusTotal reports are fetched (GET /api/v3/urls/{id}). URLs are
never submitted for scanning, so VirusTotal is not asked to visit anything on
our behalf. A URL VirusTotal has never seen counts as 'not detected' - this is
exactly the zero-hour gap the project is about, and it is reported separately.

VirusTotal is counted as detecting a URL when >= 1 engine (and, as a stricter
variant, >= 2 engines) labels it malicious or suspicious.
"""
from __future__ import annotations

import argparse
import base64
import csv
import json
import os
import random
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from evaluation.run_eval import V2_RULES, load_rows, metrics, restrict, scan_rows, score_with  # noqa: E402
from engine import DEFAULT_WEIGHTS  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "results", "vt_raw.csv")
API = "https://www.virustotal.com/api/v3/urls/"


def vt_lookup(url: str, key: str) -> dict:
    uid = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
    req = urllib.request.Request(API + uid, headers={"x-apikey": key, "accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.load(resp)
        st = data["data"]["attributes"].get("last_analysis_stats", {})
        return {"status": "found", "malicious": st.get("malicious", 0), "suspicious": st.get("suspicious", 0),
                "harmless": st.get("harmless", 0), "undetected": st.get("undetected", 0),
                "first_submission": data["data"]["attributes"].get("first_submission_date", "")}
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return {"status": "unknown", "malicious": 0, "suspicious": 0, "harmless": 0, "undetected": 0,
                    "first_submission": ""}
        if exc.code == 429:
            raise RuntimeError("VirusTotal quota exceeded - wait and re-run; progress is saved.")
        raise


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=150, help="held-out URLs (balanced) to compare")
    ap.add_argument("--recent", type=int, default=50, help="recently reported phishing URLs to compare")
    ap.add_argument("--delay", type=float, default=15.5, help="seconds between requests (free API: 4/min)")
    args = ap.parse_args(argv)
    key = os.environ.get("VT_API_KEY")
    if not key:
        sys.exit("Set the VT_API_KEY environment variable first.")

    rng = random.Random(11)
    hold = load_rows(os.path.join(HERE, "data", "dataset.csv"), "holdout")
    pos = [r for r in hold if r["label"] == 1]
    neg = [r for r in hold if r["label"] == 0]
    sample = rng.sample(pos, args.n // 2) + rng.sample(neg, args.n - args.n // 2)
    for r in sample:
        r["set"] = "holdout"
    recent = load_rows(os.path.join(HERE, "data", "recent.csv"))
    for r in recent:
        r["set"] = "recent"
    sample += rng.sample(recent, min(args.recent, len(recent)))

    done = {}
    if os.path.exists(RAW):
        with open(RAW, encoding="utf-8") as fh:
            done = {row["url"]: row for row in csv.DictReader(fh)}
    fields = ["set", "url", "label", "status", "malicious", "suspicious", "harmless", "undetected", "first_submission"]
    new_file = not os.path.exists(RAW)
    with open(RAW, "a", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        if new_file:
            w.writeheader()
        todo = [r for r in sample if r["url"] not in done]
        for i, r in enumerate(todo, 1):
            res = vt_lookup(r["url"], key)
            row = {"set": r["set"], "url": r["url"], "label": r["label"], **res}
            w.writerow(row)
            fh.flush()
            done[r["url"]] = row
            print(f"[{i}/{len(todo)}] {res['status']:7s} mal={res['malicious']:<3} {r['url'][:80]}")
            time.sleep(args.delay)

    # ---- compare on exactly the same URLs
    weights = json.load(open(os.path.join(HERE, "results", "weights_v2_refined.json")))
    bands = json.load(open(os.path.join(HERE, "results", "bands_v2_refined.json")))
    rows = [{"url": u, "label": int(d["label"]), "stratum": d["set"], "set": d["set"]} for u, d in done.items()]
    ss = {r["url"]: r for r in score_with(restrict(scan_rows(rows, DEFAULT_WEIGHTS), V2_RULES), weights, bands)}
    out = {}
    for subset in ("holdout", "recent"):
        sub = [d for d in done.values() if d["set"] == subset]
        if not sub:
            continue
        res = {"n": len(sub), "vt_unknown": sum(d["status"] == "unknown" for d in sub)}
        for name, flag in (("virustotal_>=1_engine", lambda d: int(d["malicious"]) + int(d["suspicious"]) >= 1),
                           ("virustotal_>=2_engines", lambda d: int(d["malicious"]) + int(d["suspicious"]) >= 2),
                           ("safescan_v2", lambda d: ss[d["url"]]["band"] != "safe")):
            recs = [{"label": int(d["label"]), "band": "dangerous" if flag(d) else "safe"} for d in sub]
            res[name] = metrics(recs)
        phish = [d for d in sub if int(d["label"]) == 1]
        res["phish_caught_by_safescan_not_vt"] = sum(
            1 for d in phish if ss[d["url"]]["band"] != "safe" and int(d["malicious"]) + int(d["suspicious"]) == 0)
        res["phish_caught_by_vt_not_safescan"] = sum(
            1 for d in phish if ss[d["url"]]["band"] == "safe" and int(d["malicious"]) + int(d["suspicious"]) >= 1)
        out[subset] = res
    json.dump(out, open(os.path.join(HERE, "results", "vt_comparison.json"), "w"), indent=2)
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
