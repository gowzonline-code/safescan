# Requirement-gathering kit (Chapter 4)

The Part B guide requires **at least 5 interviews** and **at least 20 questionnaire responses**.
These must be real. Nothing in this folder contains invented responses.

1. `consent_and_information_sheet.md` - read/give this to every participant first.
2. `interview_guide.md` - semi-structured interview (15-20 min, online or face-to-face).
   Record notes (not audio unless they agree), one file per participant: `P1.txt` ... `P5.txt`.
3. `questionnaire.md` - copy these questions into a Google Form exactly as written
   (keep the question wording - the analysis script matches on the short codes in brackets).
4. After you have >= 20 responses: Google Forms -> Responses -> Download (.csv), save it as
   `questionnaire_responses.csv` in this folder, then run:

       python instruments/analyse_questionnaire.py instruments/questionnaire_responses.csv

   It writes `questionnaire_summary.md` (percentages, ready to paste into Section 4.5.3)
   and charts in `instruments/charts/` for Appendix C.
5. For interviews, code each transcript with the themes in `interview_coding_template.csv`
   (1 = theme mentioned) - the summary table in Section 4.4.3 comes from those counts.
