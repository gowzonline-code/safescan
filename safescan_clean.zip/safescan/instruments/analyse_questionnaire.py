"""Analyse a Google Forms CSV export of questionnaire.md (Section 4.5.3 / Appendix C).

    python instruments/analyse_questionnaire.py instruments/questionnaire_responses.csv
"""
import os
import re
import sys
from collections import Counter

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

LIKERT = {"Q3", "Q7", "Q8", "Q10", "Q13"}
MULTI = {"Q5", "Q14"}
HERE = os.path.dirname(os.path.abspath(__file__))


def code_of(col):
    m = re.match(r"\s*\[(Q\d+)\]", col)
    return m.group(1) if m else None


def main(path):
    df = pd.read_csv(path)
    cols = {code_of(c): c for c in df.columns if code_of(c)}
    n = len(df)
    out = [f"# Questionnaire results (n = {n})", ""]
    if n < 20:
        out.append(f"**Warning: only {n} responses - the guide requires at least 20.**\n")
    os.makedirs(os.path.join(HERE, "charts"), exist_ok=True)
    for code in sorted(cols, key=lambda c: int(c[1:])):
        col = cols[code]
        s = df[col].dropna().astype(str)
        title = re.sub(r"^\s*\[Q\d+\]\s*", "", col)
        out.append(f"## {code}. {title}")
        if code == "Q15":
            for ans in s:
                out.append(f"- \"{ans.strip()}\"")
            out.append("")
            continue
        if code in MULTI:
            counts = Counter(x.strip() for v in s for x in v.split(";") if x.strip())
        else:
            counts = Counter(s)
        if code in LIKERT:
            vals = pd.to_numeric(s.str.extract(r"(\d)")[0], errors="coerce").dropna()
            agree = (vals >= 4).mean() * 100 if len(vals) else 0
            disagree = (vals <= 2).mean() * 100 if len(vals) else 0
            out.append(f"Mean {vals.mean():.2f} / 5; agree (4-5) {agree:.0f}%; disagree (1-2) {disagree:.0f}%; n={len(vals)}")
            counts = Counter(str(int(v)) for v in vals)
            order = [str(i) for i in range(1, 6)]
        else:
            order = [k for k, _ in counts.most_common()]
        out.append("")
        out.append("| Answer | Count | % |")
        out.append("|---|---|---|")
        for k in order:
            out.append(f"| {k} | {counts.get(k, 0)} | {counts.get(k, 0) / n * 100:.0f}% |")
        out.append("")
        fig, ax = plt.subplots(figsize=(6, 0.45 * len(order) + 1))
        ax.barh(order[::-1], [counts.get(k, 0) for k in order[::-1]], color="#2a78d6")
        ax.set_title(f"{code}: {title[:70]}", fontsize=9)
        ax.set_xlabel("Respondents")
        ax.spines[["top", "right"]].set_visible(False)
        fig.tight_layout()
        fig.savefig(os.path.join(HERE, "charts", f"{code}.png"), dpi=150)
        plt.close(fig)
    if "Q6" in cols:
        correct = df[cols["Q6"]].astype(str).str.contains("second", case=False).mean() * 100
        out.insert(2, f"**Q6 knowledge check: {correct:.0f}% identified the real PayPal domain correctly.**\n")
    with open(os.path.join(HERE, "questionnaire_summary.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(out))
    print("\n".join(out))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "questionnaire_responses.csv"))
