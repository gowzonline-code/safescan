# Participant information sheet and consent form

**Project:** SafeScan - An Explainable Heuristic Framework for Phishing URL Detection
**Researcher:** Gowtham Karthik Raju (PSB Academy / Coventry University, BSc (Hons) Cyber Security)
**Supervisor:** Suryanto (Ryan)

**Purpose.** I am building a web tool that checks whether a link (URL) looks like phishing and explains why.
I would like to understand how people currently decide whether to trust a link, and what they would need
from such a tool.

**What you will do.** Answer a short questionnaire (about 5 minutes) or take part in an interview
(about 15-20 minutes). You will not be asked to click any link, and no real phishing links are shown.

**Your data.** No name, email address or other identifier is recorded with your answers. Interview notes are
labelled P1, P2, ... only. Data is stored on the researcher's password-protected device, used only for this
academic project, not shared with third parties, and deleted after the module is assessed (in line with the
Singapore PDPA 2012 and the BCS Code of Conduct).

**Your rights.** Taking part is voluntary. You may skip any question and withdraw at any time before
19 October 2026 without giving a reason.

**Consent** (tick each):
- [ ] I have read the information above and had the chance to ask questions.
- [ ] I understand that participation is voluntary and that I can withdraw.
- [ ] I agree that my anonymised answers may be quoted in the project report.
- [ ] I am 18 years of age or older.

Participant code: ______  Date: ______
(For Google Forms: make the four consent statements the first, required checkbox question.)
