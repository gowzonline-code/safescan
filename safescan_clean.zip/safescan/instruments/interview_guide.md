# Semi-structured interview guide (target: 5+ participants)

Suggested mix: 2-3 everyday users (students / office staff), 1 IT support or system administrator,
1 security practitioner or lecturer. Record each participant's role category only (no names).

**Opening (1 min).** Read the information sheet; confirm consent; record role category and how often they
receive links by email/SMS/messaging apps.

**Core questions**
1. When you receive a link in an email or message, how do you decide whether it is safe to open?
2. Can you describe a time you were unsure about a link, or were caught out by one? What made it convincing?
3. What tools, if any, do you use to check a link (browser warnings, antivirus, VirusTotal, asking IT)? What do you like or dislike about them?
4. When a tool says a link is "unsafe" without saying why, what do you do? Would you trust it more or less if it explained its reasoning?
5. Here is a description of a result that shows a score, a band (safe/suspicious/dangerous) and a list of reasons. Which would you find more useful: a simple yes/no, a score, or the reasons? Why?
6. Would you want to keep a history of the links you have checked, or export a report to send to IT? Why / why not?
7. What security or privacy concerns would you have about pasting links into a web tool? (e.g. who can see them, how long they are stored)
8. (Admin/IT participants) What controls would you need as an administrator - managing users, adjusting rules, reviewing logs?

**Closing.** Anything else you would want from such a tool? Thank the participant.

Note-taking: write short bullet points per question; afterwards mark themes in `interview_coding_template.csv`.
