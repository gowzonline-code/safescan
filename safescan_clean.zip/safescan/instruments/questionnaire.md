# Questionnaire (Google Form) - target 20+ respondents

Put the short code in square brackets at the START of each question title in Google Forms
(e.g. "[Q1] How old are you?") - the analysis script groups answers by these codes.

| Code | Question | Type / options |
|---|---|---|
| Q0 | Consent statements (see information sheet) | Checkboxes, all required |
| Q1 | Which best describes you? | MC: Student / Working professional (non-IT) / IT or security professional / Other |
| Q2 | How many links do you receive by email, SMS or messaging apps in a typical day? | MC: 0-5 / 6-20 / 21-50 / More than 50 |
| Q3 | I am confident I can tell a phishing link from a real one just by reading it. | Likert 1-5 (Strongly disagree - Strongly agree) |
| Q4 | Have you ever clicked a link that later turned out to be phishing or a scam? | Yes / No / Not sure |
| Q5 | Which of these do you currently use to check a suspicious link? (tick all) | Checkboxes: Nothing / Browser warning / Antivirus / Online scanner (e.g. VirusTotal) / Ask IT or a friend / Other |
| Q6 | Which of these two links goes to PayPal? "paypal.com.secure-login.net" or "secure-login.paypal.com" | MC: The first / The second / Both / Neither / Not sure  (correct answer: the second) |
| Q7 | When a security tool says "unsafe" without explaining why, I trust its decision. | Likert 1-5 |
| Q8 | I would find it useful if a link checker explained WHY a link is risky. | Likert 1-5 |
| Q9 | Which result format would you prefer? | MC: Simple safe/unsafe / A risk score (0-100) / A band (safe/suspicious/dangerous) / Band + score + list of reasons |
| Q10 | Seeing the reasons would help me spot similar phishing links myself in future. | Likert 1-5 |
| Q11 | Would you use a free web tool to check links before clicking them? | Yes / No / Maybe |
| Q12 | Would you want to keep a history of links you have checked? | Yes / No / Maybe |
| Q13 | How important is it that a link checker does not keep or share the links you submit? | Likert 1-5 (Not important - Very important) |
| Q14 | Which features matter most to you? (tick up to 3) | Checkboxes: Speed / Explanation of reasons / Accuracy / Privacy of my data / History and reports / Works without an account |
| Q15 | What would make you trust (or not trust) a link-checking tool? | Short paragraph (optional) |
