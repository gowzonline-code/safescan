"""Development entry point: python run.py  (then open http://127.0.0.1:5000)."""
from werkzeug.serving import WSGIRequestHandler

from safescan import create_app

# Do not advertise the server software and version in the "Server" header
# (OWASP ZAP alert 10036). In production Nginx does the same with server_tokens off.
WSGIRequestHandler.version_string = lambda self: "SafeScan"

app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
