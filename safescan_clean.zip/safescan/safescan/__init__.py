"""SafeScan Flask application factory."""
from __future__ import annotations

import os
import time

import click
from flask import Flask, render_template, request
from flask_login import LoginManager
from flask_wtf.csrf import CSRFError, CSRFProtect

from . import db as dbmod
from .config import DevelopmentConfig, TestingConfig, Config
from .security import auth, rbac
from .security.audit import log_event

csrf = CSRFProtect()
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.session_protection = "strong"
login_manager.login_message = "Please log in to continue."
_last_purge = {"t": 0.0}


def create_app(env: str | None = None, overrides: dict | None = None) -> Flask:
    app = Flask(__name__, instance_relative_config=True)
    os.makedirs(app.instance_path, exist_ok=True)
    env = env or os.environ.get("SAFESCAN_ENV", "development")
    cfg_cls = {"production": Config, "development": DevelopmentConfig, "testing": TestingConfig}[env]
    app.config.from_object(cfg_cls(app.instance_path))
    if overrides:
        app.config.update(overrides)

    csrf.init_app(app)
    login_manager.init_app(app)
    login_manager.user_loader(auth.load_user)
    app.teardown_appcontext(dbmod.close_db)

    from .views import admin, main, scans, auth as auth_views
    app.register_blueprint(main.bp)
    app.register_blueprint(auth_views.bp)
    app.register_blueprint(scans.bp)
    app.register_blueprint(admin.bp)

    app.before_request(rbac.enforce_access)

    @app.before_request
    def _retention():
        # opportunistic retention purge, at most hourly
        if time.time() - _last_purge["t"] > 3600:
            _last_purge["t"] = time.time()
            n = dbmod.purge_expired()
            if n:
                log_event("system.purge", "info", f"retention purge removed {n} scans",
                          actor_name="system")

    @app.context_processor
    def _bands():
        try:
            return {"config_bands": {"suspicious": int(dbmod.get_setting("band_suspicious", "30")),
                                     "dangerous": int(dbmod.get_setting("band_dangerous", "60"))}}
        except Exception:
            return {"config_bands": None}

    @app.after_request
    def _security_headers(resp):
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        resp.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        if request.is_secure:
            resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        if request.endpoint and request.endpoint != "static":
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.errorhandler(CSRFError)
    def _csrf(e):
        log_event("access.denied", "denied", f"CSRF validation failed: {e.description}")
        return render_template("error.html", code=400, message="Your form expired or was not valid. Please try again."), 400

    for code, msg in ((403, "You do not have permission to view this page."),
                      (404, "Page not found."),
                      (413, "Request too large."),
                      (429, "Too many requests. Please wait and try again."),
                      (500, "Something went wrong.")):
        app.register_error_handler(code, lambda e, c=code, m=msg: (render_template("error.html", code=c, message=m), c))

    @app.cli.command("init-db")
    def init_db_cmd():
        """Create tables and seed rules, brands and settings."""
        dbmod.init_db()
        click.echo("Database initialised.")

    @app.cli.command("create-admin")
    @click.option("--username", prompt=True)
    @click.option("--email", prompt=True)
    @click.password_option()
    def create_admin(username, email, password):
        """Create an administrator account (there are no default accounts)."""
        problems = auth.password_problems(password, username)
        if problems:
            raise click.ClickException(" ".join(problems))
        uid = auth.create_user(username, email, password, role="admin")
        log_event("system.admin_created", "success", f"admin '{username}' created via CLI", actor_id=uid,
                  actor_name="system")
        click.echo(f"Administrator '{username}' created.")

    @app.cli.command("purge")
    def purge_cmd():
        """Apply the retention policy now."""
        n = dbmod.purge_expired()
        log_event("system.purge", "info", f"manual purge removed {n} scans", actor_name="system")
        click.echo(f"Removed {n} expired scans.")

    with app.app_context():
        dbmod.init_db()

    return app
