"""Environment-based configuration (OWASP A05: no secrets in source control,
debug disabled outside development)."""
from __future__ import annotations

import os
import secrets
from datetime import timedelta

from cryptography.fernet import Fernet


def _load_env_file(path: str) -> None:
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


class Config:
    ENV = "production"
    DEBUG = False
    TESTING = False
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_NAME = "safescan_session"
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SECURE = True
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=30)
    WTF_CSRF_TIME_LIMIT = 3600
    MAX_CONTENT_LENGTH = 16 * 1024
    RETENTION_DAYS = 90
    PASSWORD_MIN_LENGTH = 10
    LOCKOUT_THRESHOLD = 5            # failures before progressive lock-out starts
    LOCKOUT_BASE_SECONDS = 30        # doubles with each further failure
    LOCKOUT_MAX_SECONDS = 15 * 60
    RATE_LIMITS = {                  # (max requests, window seconds)
        "scan_guest_ip": (10, 3600),
        "scan_user": (60, 3600),
        "scan_ip": (120, 3600),
        "login_ip": (10, 60),
        "register_ip": (5, 3600),
    }

    def __init__(self, instance_path: str):
        _load_env_file(os.path.join(instance_path, "safescan.env"))
        self.DATABASE = os.environ.get("SAFESCAN_DATABASE", os.path.join(instance_path, "safescan.db"))
        self.SECRET_KEY = os.environ.get("SAFESCAN_SECRET_KEY")
        self.FERNET_KEY = os.environ.get("SAFESCAN_FERNET_KEY")
        self.INDEX_KEY = os.environ.get("SAFESCAN_INDEX_KEY")
        if not all((self.SECRET_KEY, self.FERNET_KEY, self.INDEX_KEY)):
            # Fail safe: production refuses to start without explicit keys.
            raise RuntimeError("SAFESCAN_SECRET_KEY, SAFESCAN_FERNET_KEY and SAFESCAN_INDEX_KEY must be set. "
                               "Run `python scripts/generate_keys.py` to create instance/safescan.env.")


class DevelopmentConfig(Config):
    ENV = "development"
    DEBUG = False                    # interactive debugger is never enabled, even in development
    SESSION_COOKIE_SECURE = False    # local http://127.0.0.1 only
    REMEMBER_COOKIE_SECURE = False

    def __init__(self, instance_path: str):
        env_path = os.path.join(instance_path, "safescan.env")
        if not os.path.exists(env_path):
            os.makedirs(instance_path, exist_ok=True)
            write_key_file(env_path)
        super().__init__(instance_path)


class TestingConfig(DevelopmentConfig):
    ENV = "testing"
    TESTING = True
    WTF_CSRF_ENABLED = True

    def __init__(self, instance_path: str):
        os.environ.setdefault("SAFESCAN_SECRET_KEY", secrets.token_hex(32))
        os.environ.setdefault("SAFESCAN_FERNET_KEY", Fernet.generate_key().decode())
        os.environ.setdefault("SAFESCAN_INDEX_KEY", secrets.token_hex(32))
        Config.__init__(self, instance_path)


def write_key_file(path: str) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("# SafeScan secrets - keep out of version control (see .gitignore)\n")
        fh.write(f"SAFESCAN_SECRET_KEY={secrets.token_hex(32)}\n")
        fh.write(f"SAFESCAN_FERNET_KEY={Fernet.generate_key().decode()}\n")
        fh.write(f"SAFESCAN_INDEX_KEY={secrets.token_hex(32)}\n")
    os.chmod(path, 0o600)
