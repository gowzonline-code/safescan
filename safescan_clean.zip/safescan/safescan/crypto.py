"""Field-level encryption at rest (Fernet = AES-128-CBC + HMAC-SHA256) and a
keyed blind index so encrypted e-mail addresses can still be checked for
uniqueness without decrypting every row."""
from __future__ import annotations

import hashlib
import hmac

from cryptography.fernet import Fernet, InvalidToken
from flask import current_app


def _fernet() -> Fernet:
    return Fernet(current_app.config["FERNET_KEY"].encode())


def encrypt(text: str) -> bytes:
    return _fernet().encrypt(text.encode("utf-8"))


def decrypt(token: bytes) -> str:
    try:
        return _fernet().decrypt(token).decode("utf-8")
    except InvalidToken:
        return "[unreadable - encryption key changed]"


def blind_index(value: str) -> str:
    key = current_app.config["INDEX_KEY"].encode()
    return hmac.new(key, value.strip().lower().encode("utf-8"), hashlib.sha256).hexdigest()
