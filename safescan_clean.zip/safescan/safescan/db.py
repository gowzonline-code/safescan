"""Data access layer. Every query uses parameter binding ('?' placeholders);
no user input is ever concatenated into SQL (OWASP A03)."""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone

from flask import current_app, g

import engine

SEED_PATH = os.path.join(os.path.dirname(__file__), "seed_config.json")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        conn = sqlite3.connect(current_app.config["DATABASE"], detect_types=0, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        g.db = conn
    return g.db


def close_db(_exc=None) -> None:
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db() -> None:
    db = get_db()
    with current_app.open_resource("schema.sql") as fh:
        db.executescript(fh.read().decode("utf-8"))
    seed()
    db.commit()


def seed() -> None:
    """Insert rules, brands and settings if absent. Weights and bands come from
    the frozen output of the evaluation (seed_config.json)."""
    db = get_db()
    cfg = json.load(open(SEED_PATH)) if os.path.exists(SEED_PATH) else {}
    weights = cfg.get("weights", engine.DEFAULT_WEIGHTS)
    for r in engine.RULES:
        db.execute(
            "INSERT OR IGNORE INTO rules (id, name, category, rationale, weight, initial_weight, enabled, "
            "requires_network, is_extension) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (r.id, r.name, r.category, r.rationale, int(weights.get(r.id, r.default_weight)), r.default_weight,
             1, int(r.requires_network), int(int(r.id[1:]) > 15)),
        )
    if db.execute("SELECT COUNT(*) FROM brands").fetchone()[0] == 0:
        for b in engine.load_default_brands():
            db.execute("INSERT INTO brands (name, domains, created_at) VALUES (?, ?, ?)",
                       (b.name, ",".join(b.domains), now()))
    bands = cfg.get("bands", engine.DEFAULT_BANDS)
    defaults = {
        "band_suspicious": str(bands["suspicious"]),
        "band_dangerous": str(bands["dangerous"]),
        "lookups_enabled": "0",
        "retention_days": str(current_app.config["RETENTION_DAYS"]),
    }
    for k, v in defaults.items():
        db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))


def get_setting(key: str, default: str = "") -> str:
    row = get_db().execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    get_db().execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                     "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))


def engine_config() -> dict:
    """Build analyse() keyword arguments from the administrator-editable tables."""
    db = get_db()
    rules = db.execute("SELECT id, weight, enabled FROM rules").fetchall()
    brands = [engine.Brand(r["name"], [d.strip() for d in r["domains"].split(",") if d.strip()])
              for r in db.execute("SELECT name, domains FROM brands ORDER BY name")]
    return {
        "weights": {r["id"]: r["weight"] for r in rules},
        "enabled": [r["id"] for r in rules if r["enabled"]],
        "brands": brands,
        "bands": {"suspicious": int(get_setting("band_suspicious", "30")),
                  "dangerous": int(get_setting("band_dangerous", "60"))},
    }


# ---------------------------------------------------------------- lookup cache

def cache_get(key: str):
    row = get_db().execute("SELECT value, expires_at FROM lookup_cache WHERE key = ?", (key,)).fetchone()
    if row and row["expires_at"] > now():
        return json.loads(row["value"])
    return None


def cache_set(key: str, value, ttl_hours: int = 24) -> None:
    exp = (datetime.now(timezone.utc) + timedelta(hours=ttl_hours)).isoformat(timespec="seconds")
    get_db().execute("INSERT INTO lookup_cache (key, value, expires_at) VALUES (?, ?, ?) "
                     "ON CONFLICT(key) DO UPDATE SET value = excluded.value, expires_at = excluded.expires_at",
                     (key, json.dumps(value), exp))
    get_db().commit()


def purge_expired() -> int:
    """Retention policy: delete scans older than retention_days (findings cascade)."""
    days = int(get_setting("retention_days", "90"))
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat(timespec="seconds")
    db = get_db()
    n = db.execute("DELETE FROM scans WHERE created_at < ?", (cutoff,)).rowcount
    db.execute("DELETE FROM lookup_cache WHERE expires_at < ?", (now(),))
    db.commit()
    return n
