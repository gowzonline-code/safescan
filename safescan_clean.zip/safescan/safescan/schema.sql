-- SafeScan database schema (SQLite). Six core entities + settings and lookup cache.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    username         TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    email_enc        BLOB    NOT NULL,              -- Fernet-encrypted at rest
    email_index      TEXT    NOT NULL UNIQUE,       -- HMAC-SHA256 blind index for uniqueness checks
    password_hash    TEXT    NOT NULL,              -- Argon2id encoded hash (salt embedded)
    role             TEXT    NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    is_active        INTEGER NOT NULL DEFAULT 1,
    session_token    TEXT    NOT NULL,              -- rotated on logout to invalidate old cookies
    failed_logins    INTEGER NOT NULL DEFAULT 0,
    locked_until     TEXT,
    created_at       TEXT    NOT NULL,
    last_login_at    TEXT
);

CREATE TABLE IF NOT EXISTS rules (
    id               TEXT    PRIMARY KEY,           -- R01..R19
    name             TEXT    NOT NULL,
    category         TEXT    NOT NULL,
    rationale        TEXT    NOT NULL,
    weight           INTEGER NOT NULL CHECK (weight BETWEEN 0 AND 100),
    initial_weight   INTEGER NOT NULL,
    enabled          INTEGER NOT NULL DEFAULT 1,
    requires_network INTEGER NOT NULL DEFAULT 0,
    is_extension     INTEGER NOT NULL DEFAULT 0,
    updated_at       TEXT,
    updated_by       INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS brands (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    name             TEXT    NOT NULL UNIQUE,
    domains          TEXT    NOT NULL,              -- comma-separated official registrable domains
    created_at       TEXT    NOT NULL,
    created_by       INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS scans (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    url_enc          BLOB    NOT NULL,              -- submitted URL, encrypted at rest
    destination_enc  BLOB    NOT NULL,              -- registrable domain, encrypted at rest
    score            INTEGER NOT NULL,
    band             TEXT    NOT NULL CHECK (band IN ('safe', 'suspicious', 'dangerous')),
    not_evaluated    TEXT    NOT NULL DEFAULT '[]', -- JSON list of skipped rules and reasons
    duration_ms      REAL    NOT NULL,
    created_at       TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_scans_user ON scans(user_id, created_at);

CREATE TABLE IF NOT EXISTS scan_findings (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id          INTEGER NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
    rule_id          TEXT    NOT NULL REFERENCES rules(id),
    weight_applied   INTEGER NOT NULL,              -- weight at scan time: explanation is reproducible later
    evidence_enc     BLOB    NOT NULL               -- evidence quotes the URL, so it is encrypted too
);
CREATE INDEX IF NOT EXISTS idx_findings_scan ON scan_findings(scan_id);
CREATE INDEX IF NOT EXISTS idx_findings_rule ON scan_findings(rule_id);

CREATE TABLE IF NOT EXISTS audit_log (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    ts               TEXT    NOT NULL,
    actor_id         INTEGER,                       -- no FK: the record must outlive the account
    actor_name       TEXT,
    event_type       TEXT    NOT NULL,
    outcome          TEXT    NOT NULL CHECK (outcome IN ('success', 'failure', 'denied', 'info')),
    source_ip        TEXT,
    detail           TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts);

-- Append-only enforcement in the database itself (defence in depth on top of the
-- application having no update/delete code path for audit records).
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;

CREATE TABLE IF NOT EXISTS settings (
    key              TEXT PRIMARY KEY,
    value            TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS lookup_cache (
    key              TEXT PRIMARY KEY,
    value            TEXT NOT NULL,
    expires_at       TEXT NOT NULL
);
