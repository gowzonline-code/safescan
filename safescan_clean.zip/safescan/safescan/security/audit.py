"""Accounting: append-only security audit log.

There is deliberately no update or delete function in this module (or anywhere
in the application) for audit records; the database additionally rejects
UPDATE/DELETE on audit_log through triggers.
"""
from __future__ import annotations

from flask import has_request_context, request
from flask_login import current_user

from ..db import get_db, now

EVENTS = {
    "auth.register", "auth.login", "auth.logout", "auth.lockout", "auth.session_rejected",
    "scan.submit", "scan.delete", "scan.delete_all", "scan.export", "scan.rate_limited", "scan.invalid",
    "access.denied", "admin.user_update", "admin.rule_update", "admin.brand_add", "admin.brand_delete",
    "admin.settings_update", "account.delete", "system.purge", "system.admin_created",
}


def client_ip() -> str:
    # The prototype is served directly; behind a reverse proxy, configure
    # werkzeug's ProxyFix so that remote_addr is the real client address.
    try:
        return request.remote_addr or "unknown"
    except RuntimeError:          # outside a request (CLI commands)
        return "system"


def log_event(event_type: str, outcome: str, detail: str = "", actor_id=None, actor_name=None,
              commit: bool = True) -> None:
    if event_type not in EVENTS:
        raise ValueError(f"unknown audit event {event_type}")
    if actor_id is None and actor_name is None:
        if has_request_context() and current_user and current_user.is_authenticated:
            actor_id, actor_name = current_user.id, current_user.username
    try:
        ip = client_ip()
    except RuntimeError:
        ip = "system"
    db = get_db()
    db.execute(
        "INSERT INTO audit_log (ts, actor_id, actor_name, event_type, outcome, source_ip, detail) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (now(), actor_id, actor_name or "anonymous", event_type, outcome, ip, detail[:500]),
    )
    if commit:
        db.commit()
