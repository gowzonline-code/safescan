"""Authentication: Argon2id password hashing, NIST SP 800-63B password policy,
progressive lock-out and the Flask-Login user model."""
from __future__ import annotations

import os
import re
import secrets
from datetime import datetime, timedelta, timezone
from functools import lru_cache

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError
from flask import current_app
from flask_login import UserMixin

from ..db import get_db, now

# argon2-cffi defaults are Argon2id (RFC 9106 low-memory profile): t=3, m=64 MiB, p=4
_ph = PasswordHasher()
_DUMMY_HASH = _ph.hash(secrets.token_hex(16))   # equalises timing for unknown usernames
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.\-]{3,32}$")
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[A-Za-z]{2,}$")


@lru_cache(maxsize=1)
def _breached() -> frozenset:
    path = os.path.join(os.path.dirname(__file__), "common_passwords.txt")
    with open(path, encoding="utf-8", errors="ignore") as fh:
        return frozenset(l.strip().lower() for l in fh if l.strip())


def password_problems(password: str, username: str = "") -> list[str]:
    """NIST SP 800-63B: length and a blocklist, no composition rules."""
    problems = []
    min_len = current_app.config["PASSWORD_MIN_LENGTH"]
    if len(password) < min_len:
        problems.append(f"Password must be at least {min_len} characters.")
    if len(password) > 128:
        problems.append("Password must be at most 128 characters.")
    if password.lower() in _breached():
        problems.append("This password appears in lists of commonly used or breached passwords.")
    if username and username.lower() in password.lower():
        problems.append("Password must not contain your username.")
    if len(set(password)) <= 2:
        problems.append("Password must not be a single repeated character.")
    return problems


def hash_password(password: str) -> str:
    return _ph.hash(password)


class User(UserMixin):
    def __init__(self, row):
        self.id = row["id"]
        self.username = row["username"]
        self.role = row["role"]
        self.active = bool(row["is_active"])
        self.session_token = row["session_token"]

    @property
    def is_active(self):
        return self.active

    @property
    def is_admin(self) -> bool:
        return self.role == "admin"

    def get_id(self) -> str:
        # The session stores id + a server-side token; rotating the token on
        # logout invalidates every copy of the old (client-side) session cookie.
        return f"{self.id}:{self.session_token}"


def load_user(user_id: str):
    try:
        uid, token = user_id.split(":", 1)
        uid = int(uid)
    except (ValueError, AttributeError):
        return None
    row = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if row is None or not secrets.compare_digest(row["session_token"], token) or not row["is_active"]:
        return None
    return User(row)


def rotate_session_token(user_id: int) -> None:
    get_db().execute("UPDATE users SET session_token = ? WHERE id = ?", (secrets.token_hex(16), user_id))
    get_db().commit()


def _parse(ts):
    return datetime.fromisoformat(ts) if ts else None


def authenticate(username: str, password: str):
    """Return (User|None, reason). reason is for the audit log only; the user
    is always shown the same generic message (no account enumeration)."""
    db = get_db()
    row = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    if row is None:
        try:
            _ph.verify(_DUMMY_HASH, password)
        except VerificationError:
            pass
        return None, "unknown username"
    locked = _parse(row["locked_until"])
    if locked and locked > datetime.now(timezone.utc):
        return None, f"account locked until {row['locked_until']}"
    try:
        _ph.verify(row["password_hash"], password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        failures = row["failed_logins"] + 1
        lock_until = None
        cfg = current_app.config
        if failures >= cfg["LOCKOUT_THRESHOLD"]:
            secs = min(cfg["LOCKOUT_MAX_SECONDS"],
                       cfg["LOCKOUT_BASE_SECONDS"] * 2 ** (failures - cfg["LOCKOUT_THRESHOLD"]))
            lock_until = (datetime.now(timezone.utc) + timedelta(seconds=secs)).isoformat(timespec="seconds")
        db.execute("UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?",
                   (failures, lock_until, row["id"]))
        db.commit()
        return None, (f"bad password (failure {failures}); locked until {lock_until}" if lock_until
                      else f"bad password (failure {failures})")
    if not row["is_active"]:
        return None, "account disabled"
    if _ph.check_needs_rehash(row["password_hash"]):
        db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (_ph.hash(password), row["id"]))
    db.execute("UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = ?, session_token = ? "
               "WHERE id = ?", (now(), secrets.token_hex(16), row["id"]))
    db.commit()
    return User(db.execute("SELECT * FROM users WHERE id = ?", (row["id"],)).fetchone()), "ok"


def create_user(username: str, email: str, password: str, role: str = "user") -> int:
    from ..crypto import blind_index, encrypt
    db = get_db()
    cur = db.execute(
        "INSERT INTO users (username, email_enc, email_index, password_hash, role, session_token, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (username, encrypt(email.strip()), blind_index(email), hash_password(password), role,
         secrets.token_hex(16), now()),
    )
    db.commit()
    return cur.lastrowid
