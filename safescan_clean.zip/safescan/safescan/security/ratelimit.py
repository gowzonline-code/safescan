"""Sliding-window rate limiter (Availability; abuse-as-reconnaissance control).

In-memory and per-process, which is appropriate for the single-process
prototype. A multi-instance deployment would move the counters to Redis.
"""
from __future__ import annotations

import threading
import time
from collections import defaultdict, deque


class RateLimiter:
    def __init__(self):
        self._hits: dict[tuple, deque] = defaultdict(deque)
        self._lock = threading.Lock()

    def hit(self, scope: str, key: str, limit: int, window: int) -> tuple[bool, int]:
        """Record a request. Returns (allowed, seconds_until_retry)."""
        now = time.monotonic()
        with self._lock:
            q = self._hits[(scope, key)]
            while q and q[0] <= now - window:
                q.popleft()
            if len(q) >= limit:
                return False, int(q[0] + window - now) + 1
            q.append(now)
            return True, 0

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


limiter = RateLimiter()
