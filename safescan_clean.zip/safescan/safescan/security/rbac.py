"""Authorisation: role-based access control with a DEFAULT-DENY policy.

Every view must declare who may reach it with one of the decorators below.
A before_request hook (enforce_access) refuses any endpoint that has no
declaration, so a forgotten decorator fails closed rather than open
(Saltzer & Schroeder: fail-safe defaults, complete mediation).
"""
from __future__ import annotations

from functools import wraps

from flask import abort, current_app, redirect, request, url_for
from flask_login import current_user

from .audit import log_event

ROLE_ORDER = {"user": 1, "admin": 2}


def public(view):
    view._access = "public"
    return view


def require_role(*roles):
    def deco(view):
        view._access = ("roles", frozenset(roles))

        @wraps(view)
        def wrapper(*a, **kw):
            return view(*a, **kw)
        wrapper._access = view._access
        return wrapper
    return deco


def login_required(view):
    return require_role("user", "admin")(view)


def admin_required(view):
    return require_role("admin")(view)


def enforce_access():
    """Registered as app.before_request."""
    if request.endpoint is None:
        return None                 # 404s fall through to the normal handler
    if request.endpoint == "static":
        return None
    view = current_app.view_functions.get(request.endpoint)
    access = getattr(view, "_access", None)
    if access is None:
        log_event("access.denied", "denied", f"undeclared endpoint {request.endpoint} (default deny)")
        abort(403)
    if access == "public":
        return None
    _, roles = access
    if not current_user.is_authenticated:
        log_event("access.denied", "denied", f"unauthenticated request to {request.endpoint}")
        return redirect(url_for("auth.login", next=request.path))
    if current_user.role not in roles:
        log_event("access.denied", "denied", f"role '{current_user.role}' refused {request.endpoint}")
        abort(403)
    return None
