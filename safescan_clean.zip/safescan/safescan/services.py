"""Glue between the web layer and the framework-independent engine."""
from __future__ import annotations

import json

import engine
from engine.lookups import make_lookup_fn
from engine.scoring import _summary, Finding

from .crypto import decrypt, encrypt
from .db import cache_get, cache_set, engine_config, get_db, get_setting, now


def run_scan(url: str) -> engine.ScanResult:
    cfg = engine_config()
    lookup_fn = None
    if get_setting("lookups_enabled", "0") == "1":
        lookup_fn = make_lookup_fn(cache_get=cache_get, cache_set=cache_set)
    return engine.analyse(url, lookup_fn=lookup_fn, **cfg)


def store_scan(user_id: int, res: engine.ScanResult) -> int:
    db = get_db()
    cur = db.execute(
        "INSERT INTO scans (user_id, url_enc, destination_enc, score, band, not_evaluated, duration_ms, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (user_id, encrypt(res.url), encrypt(res.true_destination), res.score, res.band,
         json.dumps(res.not_evaluated), res.duration_ms, now()),
    )
    sid = cur.lastrowid
    for f in res.findings:
        db.execute("INSERT INTO scan_findings (scan_id, rule_id, weight_applied, evidence_enc) VALUES (?, ?, ?, ?)",
                   (sid, f.rule_id, f.weight, encrypt(f.evidence)))
    db.commit()
    return sid


def host_parts(url: str) -> dict:
    """Split the host for display: the registrable domain is emphasised so the
    user can see who really owns the site."""
    try:
        p = engine.parse_url(url)
    except engine.URLValidationError:
        return {"prefix": "", "registrable": url, "suffix_path": ""}
    reg = p.registrable_unicode
    host = p.host_unicode
    prefix = host[: len(host) - len(reg)] if host.endswith(reg) else ""
    return {"prefix": prefix, "registrable": reg, "userinfo": p.userinfo,
            "scheme": p.scheme, "rest": (p.path or "") + (("?" + p.query) if p.query else "")}


def result_view(res: engine.ScanResult) -> dict:
    return {
        "id": None, "url": res.url, "score": res.score, "raw_score": res.raw_score, "band": res.band,
        "findings": res.findings, "not_evaluated": res.not_evaluated, "passed": res.passed,
        "destination": res.true_destination, "summary": res.summary, "host": host_parts(res.url),
        "created_at": None, "duration_ms": res.duration_ms,
    }


def load_scan(scan_id: int, user_id: int) -> dict | None:
    """Ownership is enforced IN the query: another user's scan is simply not
    found (prevents insecure direct object reference, OWASP A01)."""
    db = get_db()
    row = db.execute("SELECT * FROM scans WHERE id = ? AND user_id = ?", (scan_id, user_id)).fetchone()
    if row is None:
        return None
    frows = db.execute(
        "SELECT f.rule_id, f.weight_applied, f.evidence_enc, r.name, r.category, r.rationale "
        "FROM scan_findings f JOIN rules r ON r.id = f.rule_id WHERE f.scan_id = ? "
        "ORDER BY f.weight_applied DESC, f.rule_id", (scan_id,)).fetchall()
    findings = [Finding(fr["rule_id"], fr["name"], fr["category"], fr["weight_applied"], decrypt(fr["evidence_enc"]),
                        fr["rationale"], engine.RULES_BY_ID[fr["rule_id"]].advice) for fr in frows]
    url = decrypt(row["url_enc"])
    dest = decrypt(row["destination_enc"])
    not_eval = json.loads(row["not_evaluated"])
    raw = sum(f.weight for f in findings)
    return {
        "id": row["id"], "url": url, "score": row["score"], "raw_score": raw, "band": row["band"],
        "findings": findings, "not_evaluated": not_eval, "passed": None, "destination": dest,
        "summary": _summary(row["band"], findings, dest, not_eval), "host": host_parts(url),
        "created_at": row["created_at"], "duration_ms": row["duration_ms"],
    }


def export_scan(view: dict) -> dict:
    return {
        "tool": "SafeScan - explainable heuristic phishing URL analysis",
        "scan_id": view["id"], "scanned_at": view["created_at"], "url": view["url"],
        "true_destination": view["destination"], "score": view["score"], "band": view["band"],
        "summary": view["summary"],
        "findings": [{"rule": f.rule_id, "name": f.name, "category": f.category, "points": f.weight,
                      "evidence": f.evidence, "why_it_matters": f.rationale, "what_to_check": f.advice}
                     for f in view["findings"]],
        "checks_not_run": view["not_evaluated"],
        "disclaimer": "SafeScan analyses the address only. It reduces risk but cannot guarantee a site is safe.",
    }
