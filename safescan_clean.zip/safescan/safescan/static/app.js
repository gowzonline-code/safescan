// No inline script is allowed by the Content-Security-Policy; behaviour lives here.
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll("[data-width]").forEach(function (el) {
    var v = Math.max(0, Math.min(100, parseInt(el.getAttribute("data-width"), 10) || 0));
    el.style.width = v + "%";
  });
  document.querySelectorAll("[data-left]").forEach(function (el) {
    el.style.left = Math.max(0, Math.min(100, parseInt(el.getAttribute("data-left"), 10) || 0)) + "%";
  });
  document.querySelectorAll("form[data-confirm]").forEach(function (f) {
    f.addEventListener("submit", function (e) {
      if (!window.confirm(f.getAttribute("data-confirm"))) { e.preventDefault(); }
    });
  });
});
