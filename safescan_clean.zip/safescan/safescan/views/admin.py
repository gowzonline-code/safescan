"""Administration console: users, rules, brands, settings and the audit log.
Every change is itself audited (OWASP A08/A09)."""
from __future__ import annotations

import re

from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_login import current_user

import engine

from ..db import get_db, get_setting, now, set_setting
from ..security.audit import EVENTS, log_event
from ..security.rbac import admin_required

bp = Blueprint("admin", __name__, url_prefix="/admin")
DOMAIN_RE = re.compile(r"^(?=.{3,253}$)([a-z0-9-]{1,63}\.)+[a-z]{2,63}$")


@bp.route("/")
@admin_required
def dashboard():
    db = get_db()
    stats = {
        "users": db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        "scans": db.execute("SELECT COUNT(*) FROM scans").fetchone()[0],
        "by_band": {r["band"]: r["n"] for r in db.execute("SELECT band, COUNT(*) n FROM scans GROUP BY band")},
        "denied_24h": db.execute("SELECT COUNT(*) FROM audit_log WHERE outcome='denied' AND ts > datetime('now','-1 day')").fetchone()[0],
        "failed_logins_24h": db.execute("SELECT COUNT(*) FROM audit_log WHERE event_type IN ('auth.login','auth.lockout') "
                                        "AND outcome='failure' AND ts > datetime('now','-1 day')").fetchone()[0],
    }
    top_rules = db.execute("SELECT f.rule_id, r.name, COUNT(*) n FROM scan_findings f JOIN rules r ON r.id=f.rule_id "
                           "GROUP BY f.rule_id ORDER BY n DESC LIMIT 8").fetchall()
    recent = db.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 10").fetchall()
    return render_template("admin/dashboard.html", stats=stats, top_rules=top_rules, recent=recent)


# ------------------------------------------------------------------ users

@bp.route("/users")
@admin_required
def users():
    rows = get_db().execute("SELECT u.id, u.username, u.role, u.is_active, u.failed_logins, u.locked_until, "
                            "u.created_at, u.last_login_at, (SELECT COUNT(*) FROM scans s WHERE s.user_id=u.id) scans "
                            "FROM users u ORDER BY u.id").fetchall()
    return render_template("admin/users.html", users=rows)


@bp.route("/users/<int:user_id>", methods=["POST"])
@admin_required
def user_update(user_id):
    db = get_db()
    row = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        abort(404)
    action = request.form.get("action", "")
    if user_id == current_user.id and action in ("demote", "disable"):
        flash("You cannot demote or disable your own account.", "warning")
        return redirect(url_for("admin.users"))
    if action == "promote":
        db.execute("UPDATE users SET role='admin' WHERE id=?", (user_id,))
    elif action == "demote":
        db.execute("UPDATE users SET role='user' WHERE id=?", (user_id,))
    elif action == "disable":
        db.execute("UPDATE users SET is_active=0, session_token=lower(hex(randomblob(16))) WHERE id=?", (user_id,))
    elif action == "enable":
        db.execute("UPDATE users SET is_active=1 WHERE id=?", (user_id,))
    elif action == "unlock":
        db.execute("UPDATE users SET failed_logins=0, locked_until=NULL WHERE id=?", (user_id,))
    else:
        abort(400)
    db.commit()
    log_event("admin.user_update", "success", f"{action} user '{row['username']}' (id {user_id})")
    flash(f"User '{row['username']}': {action} done.", "success")
    return redirect(url_for("admin.users"))


# ------------------------------------------------------------------ rules

@bp.route("/rules", methods=["GET", "POST"])
@admin_required
def rules():
    db = get_db()
    if request.method == "POST":
        changes = []
        for r in db.execute("SELECT id, weight, enabled FROM rules").fetchall():
            raw = request.form.get(f"weight_{r['id']}", str(r["weight"]))
            if not raw.isdigit() or not 0 <= int(raw) <= 100:
                flash(f"{r['id']}: weight must be a whole number 0-100.", "danger")
                return redirect(url_for("admin.rules"))
            w = int(raw)
            en = 1 if request.form.get(f"enabled_{r['id']}") == "on" else 0
            if w != r["weight"] or en != r["enabled"]:
                db.execute("UPDATE rules SET weight=?, enabled=?, updated_at=?, updated_by=? WHERE id=?",
                           (w, en, now(), current_user.id, r["id"]))
                changes.append(f"{r['id']}: weight {r['weight']}->{w}, enabled {r['enabled']}->{en}")
        bands = (request.form.get("band_suspicious", ""), request.form.get("band_dangerous", ""))
        if not all(b.isdigit() for b in bands) or not 0 < int(bands[0]) < int(bands[1]) <= 100:
            flash("Band thresholds must satisfy 0 < suspicious < dangerous <= 100.", "danger")
            return redirect(url_for("admin.rules"))
        for key, val in zip(("band_suspicious", "band_dangerous"), bands):
            if get_setting(key) != val:
                changes.append(f"{key}: {get_setting(key)}->{val}")
                set_setting(key, val)
        db.commit()
        if changes:
            log_event("admin.rule_update", "success", "; ".join(changes))
            flash(f"{len(changes)} change(s) saved.", "success")
        return redirect(url_for("admin.rules"))
    rows = db.execute("SELECT * FROM rules ORDER BY id").fetchall()
    return render_template("admin/rules.html", rules=rows, bands={
        "suspicious": get_setting("band_suspicious"), "dangerous": get_setting("band_dangerous")})


# ------------------------------------------------------------------ brands

@bp.route("/brands", methods=["GET", "POST"])
@admin_required
def brands():
    db = get_db()
    if request.method == "POST":
        name = request.form.get("name", "").strip().lower()
        domains = [d.strip().lower() for d in request.form.get("domains", "").split(",") if d.strip()]
        if not re.fullmatch(r"[a-z0-9]{3,40}", name):
            flash("Brand name must be 3-40 lower-case letters or digits.", "danger")
        elif not domains or not all(DOMAIN_RE.match(d) for d in domains):
            flash("Enter one or more official domains, comma-separated (e.g. example.com, example.sg).", "danger")
        elif db.execute("SELECT 1 FROM brands WHERE name=?", (name,)).fetchone():
            flash("That brand already exists.", "warning")
        else:
            db.execute("INSERT INTO brands (name, domains, created_at, created_by) VALUES (?, ?, ?, ?)",
                       (name, ",".join(domains), now(), current_user.id))
            db.commit()
            log_event("admin.brand_add", "success", f"brand '{name}' -> {','.join(domains)}")
            flash(f"Brand '{name}' added.", "success")
        return redirect(url_for("admin.brands"))
    rows = db.execute("SELECT * FROM brands ORDER BY name").fetchall()
    return render_template("admin/brands.html", brands=rows)


@bp.route("/brands/<int:brand_id>/delete", methods=["POST"])
@admin_required
def brand_delete(brand_id):
    db = get_db()
    row = db.execute("SELECT name FROM brands WHERE id=?", (brand_id,)).fetchone()
    if row is None:
        abort(404)
    db.execute("DELETE FROM brands WHERE id=?", (brand_id,))
    db.commit()
    log_event("admin.brand_delete", "success", f"brand '{row['name']}' removed")
    flash(f"Brand '{row['name']}' removed.", "info")
    return redirect(url_for("admin.brands"))


# ------------------------------------------------------------------ settings

@bp.route("/settings", methods=["GET", "POST"])
@admin_required
def settings():
    if request.method == "POST":
        lookups = "1" if request.form.get("lookups_enabled") == "on" else "0"
        retention = request.form.get("retention_days", "")
        if not retention.isdigit() or not 1 <= int(retention) <= 3650:
            flash("Retention must be between 1 and 3650 days.", "danger")
            return redirect(url_for("admin.settings"))
        changes = []
        for k, v in (("lookups_enabled", lookups), ("retention_days", retention)):
            if get_setting(k) != v:
                changes.append(f"{k}: {get_setting(k)}->{v}")
                set_setting(k, v)
        get_db().commit()
        if changes:
            log_event("admin.settings_update", "success", "; ".join(changes))
        flash("Settings saved.", "success")
        return redirect(url_for("admin.settings"))
    return render_template("admin/settings.html", lookups=get_setting("lookups_enabled") == "1",
                           retention=get_setting("retention_days"))


# ------------------------------------------------------------------ audit log

@bp.route("/audit")
@admin_required
def audit():
    event = request.args.get("event", "")
    outcome = request.args.get("outcome", "")
    actor = request.args.get("actor", "").strip()[:64]
    page = max(1, request.args.get("page", 1, type=int))
    where, params = ["1=1"], []
    if event in EVENTS:
        where.append("event_type = ?")
        params.append(event)
    if outcome in ("success", "failure", "denied", "info"):
        where.append("outcome = ?")
        params.append(outcome)
    if actor:
        where.append("actor_name = ?")
        params.append(actor)
    clause = " AND ".join(where)          # only fixed fragments; values are bound
    db = get_db()
    total = db.execute(f"SELECT COUNT(*) FROM audit_log WHERE {clause}", params).fetchone()[0]  # nosec B608
    rows = db.execute(f"SELECT * FROM audit_log WHERE {clause} ORDER BY id DESC LIMIT 50 OFFSET ?",  # nosec B608
                      params + [(page - 1) * 50]).fetchall()
    return render_template("admin/audit.html", rows=rows, events=sorted(EVENTS), event=event, outcome=outcome,
                           actor=actor, page=page, pages=max(1, -(-total // 50)), total=total)
