"""Registration, login and logout."""
from __future__ import annotations

from urllib.parse import urlsplit

from flask import Blueprint, abort, current_app, flash, redirect, render_template, request, session, url_for
from flask_login import current_user, login_user, logout_user

from ..crypto import blind_index
from ..db import get_db
from ..security import auth
from ..security.audit import client_ip, log_event
from ..security.ratelimit import limiter
from ..security.rbac import login_required, public

bp = Blueprint("auth", __name__)
GENERIC_LOGIN_ERROR = "Invalid username or password."


def _limit(scope: str, key: str):
    limit, window = current_app.config["RATE_LIMITS"][scope]
    ok, retry = limiter.hit(scope, key, limit, window)
    if not ok:
        log_event("scan.rate_limited" if scope.startswith("scan") else "access.denied", "denied",
                  f"rate limit {scope} exceeded")
        abort(429)


def _safe_next(target: str | None) -> str:
    """Only allow local redirects after login (no open redirect)."""
    if target and target.startswith("/") and not target.startswith("//") and not urlsplit(target).netloc:
        return target
    return url_for("main.index")


@bp.route("/register", methods=["GET", "POST"])
@public
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))
    form = {"username": "", "email": ""}
    if request.method == "POST":
        _limit("register_ip", client_ip())
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        form = {"username": username, "email": email}
        errors = []
        if not auth.USERNAME_RE.match(username):
            errors.append("Username must be 3-32 characters: letters, numbers, dot, dash or underscore.")
        if not auth.EMAIL_RE.match(email) or len(email) > 254:
            errors.append("Enter a valid email address.")
        if password != confirm:
            errors.append("Passwords do not match.")
        errors += auth.password_problems(password, username)
        db = get_db()
        if not errors:
            taken = db.execute("SELECT 1 FROM users WHERE username = ? OR email_index = ?",
                               (username, blind_index(email))).fetchone()
            if taken:
                errors.append("That username or email address is already registered.")
        if errors:
            for e in errors:
                flash(e, "danger")
            log_event("auth.register", "failure", f"registration rejected for '{username[:32]}'",
                      actor_name="anonymous")
            return render_template("auth/register.html", form=form), 400
        uid = auth.create_user(username, email, password)
        log_event("auth.register", "success", "account created", actor_id=uid, actor_name=username)
        flash("Account created. Please log in.", "success")
        return redirect(url_for("auth.login"))
    return render_template("auth/register.html", form=form)


@bp.route("/login", methods=["GET", "POST"])
@public
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))
    if request.method == "POST":
        _limit("login_ip", client_ip())
        username = request.form.get("username", "").strip()[:64]
        password = request.form.get("password", "")[:256]
        user, reason = auth.authenticate(username, password)
        if user is None:
            event = "auth.lockout" if "locked" in reason else "auth.login"
            log_event(event, "failure", reason, actor_name=username or "anonymous")
            flash(GENERIC_LOGIN_ERROR, "danger")
            return render_template("auth/login.html", username=username), 401
        session.clear()                       # prevent session fixation
        login_user(user)
        session.permanent = True
        log_event("auth.login", "success", "login", actor_id=user.id, actor_name=user.username)
        return redirect(_safe_next(request.args.get("next")))
    return render_template("auth/login.html", username="")


@bp.route("/logout", methods=["POST"])
@login_required
def logout():
    uid, name = current_user.id, current_user.username
    auth.rotate_session_token(uid)            # old cookies stop working everywhere
    logout_user()
    session.clear()
    log_event("auth.logout", "success", "logout", actor_id=uid, actor_name=name)
    flash("You have been logged out.", "info")
    return redirect(url_for("main.index"))
