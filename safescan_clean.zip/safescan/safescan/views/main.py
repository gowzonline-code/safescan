"""Public pages and URL submission."""
from __future__ import annotations

from flask import Blueprint, current_app, flash, redirect, render_template, request, url_for
from flask_login import current_user

import engine

from ..db import get_db
from ..security.audit import client_ip, log_event
from ..security.ratelimit import limiter
from ..security.rbac import public
from ..services import result_view, run_scan, store_scan

bp = Blueprint("main", __name__)


@bp.route("/")
@public
def index():
    return render_template("index.html", url="")


@bp.route("/scan", methods=["POST"])
@public
def scan():
    url = request.form.get("url", "")
    limits = current_app.config["RATE_LIMITS"]
    checks = [("scan_ip", client_ip())]
    if current_user.is_authenticated:
        checks.append(("scan_user", str(current_user.id)))
    else:
        checks.append(("scan_guest_ip", client_ip()))
    for scope, key in checks:
        ok, retry = limiter.hit(scope, key, *limits[scope])
        if not ok:
            log_event("scan.rate_limited", "denied", f"{scope} limit reached; retry in {retry}s")
            flash(f"Scan limit reached. Please try again in {retry // 60 + 1} minute(s)."
                  + ("" if current_user.is_authenticated else " Registered users have a higher limit."), "warning")
            return render_template("index.html", url=url), 429
    try:
        res = run_scan(url)
    except engine.URLValidationError as exc:
        log_event("scan.invalid", "failure", str(exc))
        flash(str(exc), "danger")
        return render_template("index.html", url=url), 400
    if current_user.is_authenticated:
        sid = store_scan(current_user.id, res)
        log_event("scan.submit", "success", f"scan {sid}: band={res.band} score={res.score}")
        return redirect(url_for("scans.detail", scan_id=sid))
    log_event("scan.submit", "success", f"guest scan: band={res.band} score={res.score} (not stored)")
    return render_template("scan/result.html", r=result_view(res), guest=True)


@bp.route("/rules")
@public
def rules():
    """Transparency page: every rule, its weight and rationale (problem statement 5)."""
    rows = get_db().execute("SELECT * FROM rules ORDER BY id").fetchall()
    advice = {r.id: r.advice for r in engine.RULES}
    from ..db import get_setting
    bands = {"suspicious": get_setting("band_suspicious"), "dangerous": get_setting("band_dangerous")}
    return render_template("rules.html", rules=rows, advice=advice, bands=bands)


@bp.route("/about")
@public
def about():
    return render_template("about.html")
