"""Per-user scan history, report export and data deletion."""
from __future__ import annotations

import json

from flask import Blueprint, Response, abort, flash, redirect, render_template, request, session, url_for
from flask_login import current_user, logout_user

from ..crypto import decrypt
from ..db import get_db, get_setting
from ..security.audit import log_event
from ..security.auth import _ph
from ..security.rbac import login_required
from ..services import export_scan, load_scan

bp = Blueprint("scans", __name__, url_prefix="/scans")
PAGE = 20


@bp.route("/")
@login_required
def history():
    page = max(1, request.args.get("page", 1, type=int))
    band = request.args.get("band", "")
    db = get_db()
    where, params = "user_id = ?", [current_user.id]
    if band in ("safe", "suspicious", "dangerous"):
        where += " AND band = ?"
        params.append(band)
    total = db.execute(f"SELECT COUNT(*) FROM scans WHERE {where}", params).fetchone()[0]  # nosec B608 - fixed fragments only
    rows = db.execute(f"SELECT id, url_enc, destination_enc, score, band, created_at FROM scans WHERE {where} "  # nosec B608
                      "ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?", params + [PAGE, (page - 1) * PAGE]).fetchall()
    items = [{"id": r["id"], "url": decrypt(r["url_enc"]), "destination": decrypt(r["destination_enc"]),
              "score": r["score"], "band": r["band"], "created_at": r["created_at"]} for r in rows]
    return render_template("scan/history.html", items=items, page=page, pages=max(1, -(-total // PAGE)),
                           total=total, band=band, retention=get_setting("retention_days", "90"))


@bp.route("/<int:scan_id>")
@login_required
def detail(scan_id):
    view = load_scan(scan_id, current_user.id)
    if view is None:
        log_event("access.denied", "denied", f"scan {scan_id} not owned or not found")
        abort(404)
    return render_template("scan/result.html", r=view, guest=False)


@bp.route("/<int:scan_id>/export.<fmt>")
@login_required
def export(scan_id, fmt):
    if fmt not in ("json", "txt"):
        abort(404)
    view = load_scan(scan_id, current_user.id)
    if view is None:
        log_event("access.denied", "denied", f"export of scan {scan_id} refused")
        abort(404)
    data = export_scan(view)
    log_event("scan.export", "success", f"scan {scan_id} exported as {fmt}")
    if fmt == "json":
        body, mime = json.dumps(data, indent=2, ensure_ascii=False), "application/json"
    else:
        lines = [f"SafeScan report #{data['scan_id']} ({data['scanned_at']})", "",
                 f"URL:              {data['url']}", f"Really goes to:   {data['true_destination']}",
                 f"Score:            {data['score']}/100  ({data['band'].upper()})", "", data["summary"], ""]
        for f in data["findings"]:
            lines += [f"[{f['rule']}] {f['name']}  (+{f['points']})", f"  What we saw:    {f['evidence']}",
                      f"  Why it matters: {f['why_it_matters']}", f"  What to check:  {f['what_to_check']}", ""]
        for n in data["checks_not_run"]:
            lines.append(f"Not checked: {n['rule_id']} {n['name']} - {n['reason']}")
        lines += ["", data["disclaimer"]]
        body, mime = "\n".join(lines), "text/plain; charset=utf-8"
    return Response(body, mimetype=mime,
                    headers={"Content-Disposition": f'attachment; filename="safescan-report-{scan_id}.{fmt}"'})


@bp.route("/<int:scan_id>/delete", methods=["POST"])
@login_required
def delete(scan_id):
    db = get_db()
    n = db.execute("DELETE FROM scans WHERE id = ? AND user_id = ?", (scan_id, current_user.id)).rowcount
    db.commit()
    if not n:
        log_event("access.denied", "denied", f"delete of scan {scan_id} refused")
        abort(404)
    log_event("scan.delete", "success", f"scan {scan_id} deleted by owner")
    flash("Scan deleted.", "info")
    return redirect(url_for("scans.history"))


@bp.route("/delete-all", methods=["POST"])
@login_required
def delete_all():
    db = get_db()
    n = db.execute("DELETE FROM scans WHERE user_id = ?", (current_user.id,)).rowcount
    db.commit()
    log_event("scan.delete_all", "success", f"{n} scans deleted by owner")
    flash(f"{n} scan(s) deleted.", "info")
    return redirect(url_for("scans.history"))


@bp.route("/account", methods=["GET", "POST"])
@login_required
def account():
    db = get_db()
    row = db.execute("SELECT username, email_enc, created_at, role FROM users WHERE id = ?",
                     (current_user.id,)).fetchone()
    if request.method == "POST":
        password = request.form.get("password", "")
        full = db.execute("SELECT password_hash FROM users WHERE id = ?", (current_user.id,)).fetchone()
        try:
            _ph.verify(full["password_hash"], password)
        except Exception:
            flash("Password incorrect - account not deleted.", "danger")
            return redirect(url_for("scans.account"))
        if current_user.is_admin and db.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND is_active=1").fetchone()[0] <= 1:
            flash("You are the only administrator; promote another admin first.", "warning")
            return redirect(url_for("scans.account"))
        uid, name = current_user.id, current_user.username
        db.execute("DELETE FROM users WHERE id = ?", (uid,))      # scans and findings cascade
        db.commit()
        log_event("account.delete", "success", "account and all scan data deleted by owner",
                  actor_id=uid, actor_name=name)
        logout_user()
        session.clear()
        flash("Your account and all of your scan history have been deleted.", "info")
        return redirect(url_for("main.index"))
    return render_template("scan/account.html", username=row["username"], email=decrypt(row["email_enc"]),
                           created=row["created_at"], role=row["role"],
                           count=db.execute("SELECT COUNT(*) FROM scans WHERE user_id = ?",
                                            (current_user.id,)).fetchone()[0],
                           retention=get_setting("retention_days", "90"))
