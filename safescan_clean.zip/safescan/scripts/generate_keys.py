"""Create instance/safescan.env with fresh random keys (never commit this file)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from safescan.config import write_key_file  # noqa: E402

path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "instance", "safescan.env")
os.makedirs(os.path.dirname(path), exist_ok=True)
if os.path.exists(path):
    sys.exit(f"{path} already exists - refusing to overwrite (existing encrypted data would become unreadable).")
write_key_file(path)
print(f"Wrote {path}")
