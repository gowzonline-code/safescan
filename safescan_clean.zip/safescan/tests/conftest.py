import os
import re
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from safescan import create_app  # noqa: E402
from safescan.security.ratelimit import limiter  # noqa: E402

PASSWORD = "correct horse battery staple"


@pytest.fixture
def app(tmp_path):
    limiter.reset()
    app = create_app("testing", {"DATABASE": str(tmp_path / "test.db")})
    yield app
    limiter.reset()


@pytest.fixture
def client(app):
    return app.test_client()


def csrf(client, path="/"):
    r = client.get(path)
    m = re.search(rb'name="csrf_token" value="([^"]+)"', r.data)
    return m.group(1).decode() if m else ""


def register(client, username="alice", email=None, password=PASSWORD):
    tok = csrf(client, "/register")
    return client.post("/register", data={"username": username, "email": email or f"{username}@example.org",
                                          "password": password, "confirm": password, "csrf_token": tok})


def login(client, username="alice", password=PASSWORD):
    tok = csrf(client, "/login")
    return client.post("/login", data={"username": username, "password": password, "csrf_token": tok})


def scan(client, url):
    tok = csrf(client, "/")
    return client.post("/scan", data={"url": url, "csrf_token": tok})


def make_admin(app, username):
    with app.app_context():
        from safescan.db import get_db
        get_db().execute("UPDATE users SET role='admin' WHERE username=?", (username,))
        get_db().commit()
