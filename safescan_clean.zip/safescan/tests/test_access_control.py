"""ST-Z: authorisation (RBAC, default deny, object ownership) and CSRF."""
import re

from conftest import csrf, login, make_admin, register, scan

from safescan.db import get_db


def scan_id(resp):
    return int(re.search(r"/scans/(\d+)", resp.headers["Location"]).group(1))


def test_unauthenticated_user_redirected_to_login(client):
    r = client.get("/scans/")
    assert r.status_code == 302 and "/login" in r.headers["Location"]


def test_regular_user_cannot_reach_admin(app, client):
    register(client)
    login(client)
    for path in ("/admin/", "/admin/users", "/admin/rules", "/admin/audit", "/admin/brands", "/admin/settings"):
        assert client.get(path).status_code == 403, path
    with app.app_context():
        assert get_db().execute("SELECT COUNT(*) FROM audit_log WHERE event_type='access.denied'").fetchone()[0] >= 6


def test_admin_can_reach_admin(app, client):
    register(client)
    make_admin(app, "alice")
    login(client)
    assert client.get("/admin/").status_code == 200


def test_default_deny_for_undeclared_endpoint(app):
    @app.route("/forgot-to-protect")
    def forgot():
        return "secret"
    assert app.test_client().get("/forgot-to-protect").status_code == 403


def test_idor_other_users_scan_not_visible(app):
    a, b = app.test_client(), app.test_client()
    register(a, "alice"); login(a, "alice")
    register(b, "bob"); login(b, "bob")
    sid = scan_id(scan(a, "https://example.com/"))
    assert a.get(f"/scans/{sid}").status_code == 200
    assert b.get(f"/scans/{sid}").status_code == 404
    assert b.get(f"/scans/{sid}/export.json").status_code == 404
    assert b.post(f"/scans/{sid}/delete", data={"csrf_token": csrf(b)}).status_code == 404
    assert a.get(f"/scans/{sid}").status_code == 200          # still there


def test_csrf_required_on_state_change(client):
    register(client)
    login(client)
    assert client.post("/scan", data={"url": "https://example.com/"}).status_code == 400
    assert client.post("/logout").status_code == 400


def test_user_cannot_self_promote_by_form_tampering(app, client):
    register(client)
    login(client)
    r = client.post("/admin/users/1", data={"action": "promote", "csrf_token": csrf(client)})
    assert r.status_code == 403
    with app.app_context():
        assert get_db().execute("SELECT role FROM users WHERE id=1").fetchone()[0] == "user"
