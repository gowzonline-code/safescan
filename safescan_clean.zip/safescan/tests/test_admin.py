"""IT-ADM: administration functions and their auditing."""
from conftest import csrf, login, make_admin, register, scan

from safescan.db import get_db


def admin_client(app):
    c = app.test_client()
    register(c, "root"); make_admin(app, "root"); login(c, "root")
    return c


def rule_form(app, **overrides):
    with app.app_context():
        rows = get_db().execute("SELECT id, weight, enabled FROM rules").fetchall()
    data = {f"weight_{r['id']}": str(r["weight"]) for r in rows}
    data.update({f"enabled_{r['id']}": "on" for r in rows if r["enabled"]})
    data.update({"band_suspicious": "9", "band_dangerous": "21"})
    data.update(overrides)
    return data


def test_weight_change_applies_and_is_audited(app):
    c = admin_client(app)
    data = rule_form(app, weight_R11="40", csrf_token=csrf(c, "/admin/rules"))
    c.post("/admin/rules", data=data)
    r = scan(c, "https://faceboook.com/")
    sid = r.headers["Location"].rsplit("/", 1)[1]
    assert b"+40" in c.get(f"/scans/{sid}").data
    with app.app_context():
        d = get_db().execute("SELECT detail FROM audit_log WHERE event_type='admin.rule_update'").fetchone()[0]
    assert "R11" in d


def test_invalid_weight_rejected(app):
    c = admin_client(app)
    c.post("/admin/rules", data=rule_form(app, weight_R01="500", csrf_token=csrf(c, "/admin/rules")))
    with app.app_context():
        assert get_db().execute("SELECT weight FROM rules WHERE id='R01'").fetchone()[0] != 500


def test_disable_rule(app):
    c = admin_client(app)
    data = rule_form(app, csrf_token=csrf(c, "/admin/rules"))
    data.pop("enabled_R01")
    c.post("/admin/rules", data=data)
    r = c.get(c.post("/scan", data={"url": "http://203.0.113.9/", "csrf_token": csrf(c)}).headers["Location"])
    assert b"R01" not in r.data


def test_brand_add_makes_new_brand_detectable(app):
    c = admin_client(app)
    c.post("/admin/brands", data={"name": "grabpay", "domains": "grab.com", "csrf_token": csrf(c, "/admin/brands")})
    r = c.get(c.post("/scan", data={"url": "https://grabpay-rewards.com/", "csrf_token": csrf(c)}).headers["Location"])
    assert b"grabpay" in r.data and b"R19" in r.data


def test_admin_cannot_demote_self(app):
    c = admin_client(app)
    c.post("/admin/users/1", data={"action": "demote", "csrf_token": csrf(c, "/admin/users")})
    with app.app_context():
        assert get_db().execute("SELECT role FROM users WHERE id=1").fetchone()[0] == "admin"


def test_disable_user_kills_their_session(app):
    c = admin_client(app)
    u = app.test_client(); register(u, "eve"); login(u, "eve")
    assert u.get("/scans/").status_code == 200
    c.post("/admin/users/2", data={"action": "disable", "csrf_token": csrf(c, "/admin/users")})
    assert u.get("/scans/").status_code == 302


def test_audit_viewer_filters(app):
    c = admin_client(app)
    r = c.get("/admin/audit?event=auth.login&outcome=success")
    assert r.status_code == 200 and b"auth.login" in r.data
