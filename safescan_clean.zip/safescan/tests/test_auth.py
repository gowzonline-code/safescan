"""ST-A: authentication (registration policy, hashing, login, lock-out, sessions)."""
from conftest import PASSWORD, csrf, login, register

from safescan.db import get_db


def test_register_and_login(client):
    assert register(client).status_code == 302
    r = login(client)
    assert r.status_code == 302
    assert b"alice" in client.get("/").data


def test_password_stored_as_argon2id(app, client):
    register(client)
    with app.app_context():
        h = get_db().execute("SELECT password_hash FROM users").fetchone()[0]
    assert h.startswith("$argon2id$") and PASSWORD not in h


def test_password_policy_length_and_breached_list(client):
    assert register(client, password="short").status_code == 400
    assert register(client, username="bob", password="qwertyuiop").status_code == 400   # in breached list
    assert register(client, username="carol", password="carolcarol123").status_code == 400  # contains username


def test_no_composition_rules(client):
    # NIST SP 800-63B: a long lower-case passphrase is acceptable
    assert register(client, password="purple elephants dance quietly").status_code == 302


def test_duplicate_username_or_email_rejected(client):
    register(client)
    assert register(client, username="alice2", email="ALICE@example.org").status_code == 400
    assert register(client, username="ALICE", email="other@example.org").status_code == 400


def test_login_failure_message_is_generic(client):
    register(client)
    a = login(client, password="wrong password here").data
    b = login(client, username="nobody").data
    assert b"Invalid username or password." in a and b"Invalid username or password." in b


def test_progressive_lockout(app, client):
    register(client)
    for _ in range(5):
        login(client, password="wrong password here")
    with app.app_context():
        row = get_db().execute("SELECT failed_logins, locked_until FROM users").fetchone()
    assert row["failed_logins"] == 5 and row["locked_until"]
    assert login(client).status_code == 401          # correct password refused while locked
    with app.app_context():
        events = [r[0] for r in get_db().execute("SELECT event_type FROM audit_log")]
    assert "auth.lockout" in events


def test_login_rate_limited_per_ip(client):
    for _ in range(10):
        login(client, username="x", password="y" * 12)
    assert login(client, username="x", password="y" * 12).status_code == 429


def test_session_cleared_on_login_prevents_fixation(client):
    register(client)
    with client.session_transaction() as s:
        s["planted"] = "attacker-value"
    login(client)
    with client.session_transaction() as s:
        assert "planted" not in s


def test_logout_invalidates_replayed_cookie(app, client):
    register(client)
    login(client)
    cookie = client.get_cookie("safescan_session").value
    client.post("/logout", data={"csrf_token": csrf(client)})
    other = app.test_client()
    other.set_cookie("safescan_session", cookie)
    assert other.get("/scans/").status_code == 302            # old session no longer authenticates


def test_open_redirect_blocked_after_login(client):
    register(client)
    tok = csrf(client, "/login")
    r = client.post("/login?next=https://evil.example/", data={"username": "alice", "password": PASSWORD,
                                                                "csrf_token": tok})
    assert r.headers["Location"] in ("/", "http://localhost/")


def test_session_cookie_flags(client):
    register(client)
    login(client)
    cookie = client.get_cookie("safescan_session")
    assert cookie.http_only and cookie.same_site == "Lax"
