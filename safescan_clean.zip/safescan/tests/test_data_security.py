"""ST-D: confidentiality at rest, audit integrity, retention, injection and output encoding."""
import re
import sqlite3

import pytest
from conftest import csrf, login, make_admin, register, scan

from safescan.db import get_db, purge_expired


def test_url_and_email_encrypted_at_rest(app, client):
    register(client, email="secret.person@example.org"); login(client)
    scan(client, "https://very-unique-marker-domain.com/private/path")
    raw = open(app.config["DATABASE"], "rb").read()
    assert b"very-unique-marker-domain" not in raw and b"secret.person" not in raw


def test_audit_log_is_append_only_in_database(app, client):
    register(client)
    with app.app_context():
        db = get_db()
        with pytest.raises(sqlite3.DatabaseError):
            db.execute("UPDATE audit_log SET outcome='success'")
        with pytest.raises(sqlite3.DatabaseError):
            db.execute("DELETE FROM audit_log")


def test_audit_records_actor_ip_outcome(app, client):
    register(client); login(client)
    with app.app_context():
        row = get_db().execute("SELECT * FROM audit_log WHERE event_type='auth.login' AND outcome='success'").fetchone()
    assert row["actor_name"] == "alice" and row["source_ip"] and row["ts"]


def test_retention_purge(app, client):
    register(client); login(client)
    scan(client, "https://example.com/")
    with app.app_context():
        db = get_db()
        db.execute("UPDATE scans SET created_at='2000-01-01T00:00:00+00:00'"); db.commit()
        assert purge_expired() == 1
        assert db.execute("SELECT COUNT(*) FROM scan_findings").fetchone()[0] == 0


def test_account_deletion_cascades_but_audit_survives(app, client):
    register(client); login(client)
    scan(client, "http://203.0.113.9/")
    client.post("/scans/account", data={"password": "correct horse battery staple", "csrf_token": csrf(client, "/scans/account")})
    with app.app_context():
        db = get_db()
        assert db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM scans").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM audit_log WHERE event_type='account.delete'").fetchone()[0] == 1


def test_xss_payload_in_url_is_output_encoded(client):
    r = scan(client, "http://example.com/<script>alert(1)</script>")
    assert b"<script>alert(1)</script>" not in r.data and b"&lt;script&gt;" in r.data


def test_scanned_url_never_rendered_as_link(client):
    r = scan(client, "https://evil.example/login")
    assert b'href="https://evil.example' not in r.data


def test_sql_injection_in_login_is_inert(app, client):
    register(client)
    assert login(client, username="alice' OR '1'='1", password="x' OR '1'='1").status_code == 401
    assert login(client, username="alice'; DROP TABLE users;--").status_code == 401
    with app.app_context():
        assert get_db().execute("SELECT COUNT(*) FROM users").fetchone()[0] == 1


def test_sql_injection_in_audit_filter_is_inert(app, client):
    register(client); make_admin(app, "alice"); login(client)
    r = client.get("/admin/audit?actor=x' OR '1'='1&event=auth.login' --")
    assert r.status_code == 200 and b"0 matching record" in r.data


def test_security_headers(client):
    h = client.get("/").headers
    assert "script-src 'self'" in h["Content-Security-Policy"] and h["X-Frame-Options"] == "DENY"
    assert h["X-Content-Type-Options"] == "nosniff" and h["Referrer-Policy"] == "no-referrer"
