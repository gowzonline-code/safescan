"""UT-L: SSRF defences and lookup handling for the optional increment-5 modules."""
import datetime as dt
import socket

import pytest

from engine import lookups, parse_url
from engine.lookups import SSRFBlocked, domain_age_days, make_lookup_fn, resolve_safe


def fake_dns(addr):
    def _g(host, port, proto=0):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (addr, port))]
    return _g


@pytest.mark.parametrize("addr", ["127.0.0.1", "10.0.0.5", "192.168.1.10", "172.16.0.1", "169.254.169.254",
                                  "0.0.0.0", "224.0.0.1", "100.64.0.1"])
def test_ssrf_blocks_non_public_addresses(monkeypatch, addr):
    monkeypatch.setattr(socket, "getaddrinfo", fake_dns(addr))
    with pytest.raises(SSRFBlocked):
        resolve_safe("attacker.example", 443)


def test_ssrf_blocks_disallowed_ports():
    with pytest.raises(SSRFBlocked):
        resolve_safe("example.com", 22)


def test_ssrf_allows_public_address(monkeypatch):
    monkeypatch.setattr(socket, "getaddrinfo", fake_dns("93.184.216.34"))
    assert resolve_safe("example.com", 443) == "93.184.216.34"


def test_redirect_check_refuses_internal_target(monkeypatch):
    monkeypatch.setattr(socket, "getaddrinfo", fake_dns("127.0.0.1"))
    fn = make_lookup_fn(do_whois=False, do_tls=True)
    res = fn(parse_url("https://internal.example/"))
    assert res.redirect_hops is None and "non-public" in res.redirect_error
    assert res.cert_age_days is None and "non-public" in res.cert_error


def test_whois_age_parsing():
    created = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=3)
    assert domain_age_days("x.com", whois_fn=lambda d: {"creation_date": [created, created]}) == 3


def test_whois_failure_is_reported_not_raised():
    def bad(_):
        raise ConnectionError("rate limited")
    res = make_lookup_fn(do_tls=False, do_redirects=False, whois_fn=bad)(parse_url("https://example.com/"))
    assert res.domain_age_days is None and "WHOIS" in res.domain_age_error


def test_lookup_cache_is_used():
    store = {"whois:example.com": 5}
    res = make_lookup_fn(cache_get=store.get, cache_set=store.__setitem__, do_tls=False, do_redirects=False,
                         whois_fn=lambda d: (_ for _ in ()).throw(AssertionError("should hit cache")))(
        parse_url("https://example.com/"))
    assert res.domain_age_days == 5
