"""UT-P: URL validation and parsing (engine/parser.py)."""
import pytest

from engine.parser import URLValidationError, parse_url


@pytest.mark.parametrize("bad", ["", "   ", "javascript:alert(1)", "data:text/html,hi", "file:///etc/passwd",
                                 "ftp://example.com", "http://exa mple.com", "http://ex\x00ample.com",
                                 "http://" + "a" * 2100 + ".com", "http://", "mailto:a@b.com"])
def test_rejects_invalid_or_unsafe_input(bad):
    with pytest.raises(URLValidationError):
        parse_url(bad)


def test_adds_scheme_and_lowercases_host():
    p = parse_url("WWW.Example.COM/Path")
    assert p.normalised.startswith("http://") and p.host == "www.example.com" and p.path == "/Path"


def test_registrable_domain_uses_public_suffix_list():
    p = parse_url("https://a.b.example.co.uk/x")
    assert (p.subdomain, p.domain, p.suffix, p.registrable) == ("a.b", "example", "co.uk", "example.co.uk")


def test_private_suffix_hosting_platforms():
    # github.io is a public suffix (PSL private section): each user site is its own registrable domain
    assert parse_url("https://victim.github.io/login").registrable == "victim.github.io"


def test_userinfo_is_separated_from_host():
    p = parse_url("http://www.paypal.com@evil.example.net/")
    assert p.userinfo == "www.paypal.com" and p.host == "evil.example.net"


@pytest.mark.parametrize("url,ip", [("http://192.168.1.1/", "192.168.1.1"), ("http://3232235777/", "192.168.1.1"),
                                    ("http://0xC0A80101/", "192.168.1.1"), ("http://[::1]/", "::1")])
def test_ip_hosts_including_obfuscated_forms(url, ip):
    p = parse_url(url)
    assert p.is_ip and p.ip_value == ip


def test_idn_round_trip():
    p = parse_url("https://xn--pypal-4ve.com/")
    assert p.host == "xn--pypal-4ve.com" and p.host_unicode == "pаypal.com"
    q = parse_url("https://pаypal.com/")
    assert q.host == "xn--pypal-4ve.com"
