"""UT-R: every heuristic rule fires on a positive case and stays silent on a negative case."""
import pytest

from engine import analyse
from engine.rules import CORE_RULE_IDS, EXTENSION_RULE_IDS

CASES = {
    "R01": ("http://203.0.113.9/login", "https://example.com/"),
    "R02": ("http://www.apple.com@203.0.113.9/", "https://example.com/a@b"),
    "R03": ("http://a.b.c.d.example.com/", "http://a.b.example.com/"),
    "R04": ("https://example.com/" + "a" * 80, "https://example.com/short"),
    "R05": ("https://my-secure-account-update-portal.com/", "https://my-site.com/"),
    "R06": ("https://a1b2c3d4e5.com/", "https://example2.com/"),
    "R07": ("https://shop-deals.xyz/", "https://shop-deals.com/"),
    "R08": ("https://xn--pypal-4ve.com/", "https://paypal.com/"),
    "R09": ("https://pаypal.com/", "https://пример.com/"),
    "R10": ("https://paypa1.com/", "https://paypal.com/"),
    "R11": ("https://faceboook.com/", "https://facebook.com/"),
    "R12": ("https://login.example.net/paypal/verify", "https://www.paypal.com/signin"),
    "R16": ("https://example.net/account/verify", "https://example.net/blog/post"),
    "R17": ("https://my-site.pages.dev/", "https://my-site.com/"),
    "R18": ("https://example.net/x?email=victim@corp.com", "https://example.net/x?q=hello"),
    "R19": ("https://paypal-secure-login.com/", "https://paypal.com/"),
}


@pytest.mark.parametrize("rule", sorted(CASES))
def test_rule_positive_and_negative(rule):
    pos, neg = CASES[rule]
    assert rule in [f.rule_id for f in analyse(pos).findings], f"{rule} should fire on {pos}"
    assert rule not in [f.rule_id for f in analyse(neg).findings], f"{rule} should not fire on {neg}"


def test_every_offline_rule_is_covered():
    assert set(CASES) == (set(CORE_RULE_IDS) - {"R13", "R14", "R15"}) | set(EXTENSION_RULE_IDS)


def test_official_brand_domains_never_flagged_for_brand():
    for url in ("https://www.paypal.com/signin", "https://amazon.co.jp/", "https://login.microsoftonline.com/",
                "https://www.dbs.com.sg/ibanking"):
        ids = [f.rule_id for f in analyse(url).findings]
        assert not {"R10", "R11", "R12", "R19"} & set(ids), url


def test_hosting_platform_own_homepage_not_flagged():
    assert "R17" not in [f.rule_id for f in analyse("https://blogspot.com/").findings]
    assert "R17" not in [f.rule_id for f in analyse("https://www.blogspot.com/").findings]
    assert "R17" in [f.rule_id for f in analyse("https://someone.blogspot.com/").findings]


def test_one_impersonation_is_not_double_counted():
    ids = [f.rule_id for f in analyse("https://paypa1.com/").findings]
    assert "R10" in ids and "R11" not in ids


def test_evidence_is_specific_to_the_url():
    f = [f for f in analyse("http://203.0.113.9/").findings if f.rule_id == "R01"][0]
    assert "203.0.113.9" in f.evidence


def test_homograph_evidence_shows_decoded_name():
    f = [f for f in analyse("https://xn--pypal-4ve.com/").findings if f.rule_id == "R08"][0]
    assert "pаypal" in f.evidence
