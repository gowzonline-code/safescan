"""IT: scan submission, history, export, guest limits."""
import json
import re

from conftest import csrf, login, register, scan

from safescan.db import get_db


def test_guest_scan_shows_result_but_is_not_stored(app, client):
    r = scan(client, "https://paypal-secure-login.xyz/account/verify")
    assert r.status_code == 200 and b"Why this score?" in r.data and b"R19" in r.data
    with app.app_context():
        assert get_db().execute("SELECT COUNT(*) FROM scans").fetchone()[0] == 0


def test_guest_rate_limit(app, client):
    for _ in range(10):
        assert scan(client, "https://example.com/").status_code == 200
    assert scan(client, "https://example.com/").status_code == 429
    with app.app_context():
        assert get_db().execute("SELECT COUNT(*) FROM audit_log WHERE event_type='scan.rate_limited'").fetchone()[0] == 1


def test_invalid_url_rejected_with_specific_message(client):
    r = scan(client, "javascript:alert(1)")
    assert r.status_code == 400 and b"not supported" in r.data


def test_user_scan_stored_with_findings_and_history(app, client):
    register(client); login(client)
    r = scan(client, "http://203.0.113.9/paypal/login")
    sid = int(re.search(r"/scans/(\d+)", r.headers["Location"]).group(1))
    page = client.get(f"/scans/{sid}").data
    assert b"R01" in page and b"203.0.113.9" in page
    assert b"203.0.113.9" in client.get("/scans/").data
    with app.app_context():
        assert get_db().execute("SELECT COUNT(*) FROM scan_findings WHERE scan_id=?", (sid,)).fetchone()[0] >= 2


def test_export_json_and_text(client):
    register(client); login(client)
    sid = int(re.search(r"/scans/(\d+)", scan(client, "https://faceboook.com/").headers["Location"]).group(1))
    data = json.loads(client.get(f"/scans/{sid}/export.json").data)
    assert data["true_destination"] == "faceboook.com" and data["findings"][0]["rule"] == "R11"
    txt = client.get(f"/scans/{sid}/export.txt")
    assert txt.status_code == 200 and b"Why it matters" in txt.data and "attachment" in txt.headers["Content-Disposition"]


def test_explanation_reproducible_after_weight_change(app, client):
    register(client); login(client)
    sid = int(re.search(r"/scans/(\d+)", scan(client, "https://faceboook.com/").headers["Location"]).group(1))
    before = client.get(f"/scans/{sid}/export.json").data
    with app.app_context():
        get_db().execute("UPDATE rules SET weight=1 WHERE id='R11'"); get_db().commit()
    assert client.get(f"/scans/{sid}/export.json").data == before


def test_delete_scan_and_delete_all(app, client):
    register(client); login(client)
    for u in ("https://a.com/", "https://b.com/", "https://c.com/"):
        scan(client, u)
    client.post("/scans/1/delete", data={"csrf_token": csrf(client)})
    with app.app_context():
        assert get_db().execute("SELECT COUNT(*) FROM scans").fetchone()[0] == 2
    client.post("/scans/delete-all", data={"csrf_token": csrf(client)})
    with app.app_context():
        assert get_db().execute("SELECT COUNT(*) FROM scans").fetchone()[0] == 0
