"""UT-S: scoring, banding, explanation consistency and graceful degradation."""
from engine import LookupResults, analyse, assign_band


def test_score_is_sum_of_finding_weights():
    r = analyse("https://paypal-secure-login.xyz/account/verify?email=a@b.com")
    assert r.score == min(100, sum(f.weight for f in r.findings)) and r.raw_score == sum(f.weight for f in r.findings)


def test_score_is_capped_at_100():
    w = {k: 50 for k in ("R07", "R16", "R19")}
    r = analyse("https://paypal-secure-login.xyz/account/verify", weights=w)
    assert r.raw_score > 100 and r.score == 100


def test_band_boundaries():
    b = {"suspicious": 30, "dangerous": 60}
    assert [assign_band(s, b) for s in (0, 29, 30, 59, 60, 100)] == \
        ["safe", "safe", "suspicious", "suspicious", "dangerous", "dangerous"]


def test_disabled_rule_does_not_fire():
    r = analyse("http://203.0.113.9/", enabled=["R02"])
    assert r.findings == []


def test_network_rules_reported_as_not_evaluated_when_lookups_off():
    r = analyse("https://example.com/")
    assert {n["rule_id"] for n in r.not_evaluated} == {"R13", "R14", "R15"}


def test_lookup_failure_degrades_gracefully():
    def boom(_):
        raise TimeoutError("whois timeout")
    r = analyse("https://example.com/", lookup_fn=boom)
    assert r.band == "safe" and len(r.not_evaluated) == 3 and "failed" in r.not_evaluated[0]["reason"]


def test_lookup_results_are_scored():
    r = analyse("https://example.com/", lookup_fn=lambda p: LookupResults(domain_age_days=2, cert_age_days=1,
                                                                          redirect_hops=4))
    assert {"R13", "R14", "R15"} <= {f.rule_id for f in r.findings} and r.not_evaluated == []


def test_partial_lookup_failure_omits_only_that_rule():
    r = analyse("https://example.com/", lookup_fn=lambda p: LookupResults(domain_age_days=400,
                                                                          cert_error="timeout", redirect_hops=0))
    assert [n["rule_id"] for n in r.not_evaluated] == ["R14"]


def test_deterministic():
    a, b = analyse("https://paypa1.com/login"), analyse("https://paypa1.com/login")
    assert (a.score, [f.rule_id for f in a.findings]) == (b.score, [f.rule_id for f in b.findings])


def test_scan_without_external_lookup_is_fast():
    r = analyse("https://paypal.com.secure.example.xyz/" + "x" * 100)
    assert r.duration_ms < 5000          # NFR: under five seconds without lookups (typically < 2 ms)
